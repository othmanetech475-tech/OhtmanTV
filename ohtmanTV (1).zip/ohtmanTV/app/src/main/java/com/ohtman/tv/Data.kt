package com.ohtman.tv

data class Channel(val id: String, val name: String, val url: String, val emoji: String, val desc: String, val color: Long)
data class Section(val title: String, val icon: String, val channels: List<Channel>)
data class Match(val league: String, val home: String, val away: String, val day: String, val time: String, val live: Boolean, val channelId: String?, val score: String? = null, val finished: Boolean = false)

// ⚠️ بدّل الروابط التجريبية بروابط قنواتك (m3u8 / mpd)

val alArabiya = Channel("alarabiya", "العربية", "https://live.alarabiya.net/alarabiapublish/alarabiya.smil/playlist.m3u8", "📰", "قناة العربية الإخبارية - بث مباشر", 0xFFB71C1C)

val sections = listOf(
    Section("الأخبار", "📰", listOf(alArabiya)),
    Section("الرياضة", "⚽", emptyList()),
    Section("الأفلام", "🎬", emptyList()),
    Section("الأطفال", "🧸", listOf(
        Channel("spacetoon", "سبيستون", "https://live-uae-next.spacetoongo.com/ST_MENA_NEXT/hls/r9p2hjipmw2kl.m3u8", "🧸", "قناة سبيستون - عالم الأطفال", 0xFF7B1FA2))),
)

// 📺 ربط الدوريات بالقنوات الناقلة (اسم الدوري كما يأتي من الـ API ← معرّف القناة)
// مثال: "Premier League" to "alarabiya"  (المعرّف id للقناة في قسم الأدمن)
val leagueChannels = mapOf<String, String>()

data class Social(val label: String, val glyph: String, val color: Long, val url: String)

// ⚠️ بدّل الروابط بحساباتك الحقيقية
val socials = listOf(
    Social("تيليجرام", "✈", 0xFF229ED9, "https://t.me/ohtmanTV"),
    Social("واتساب", "W", 0xFF25D366, "https://wa.me/0000000000"),
    Social("فيسبوك", "f", 0xFF1877F2, "https://facebook.com/ohtmanTV"),
    Social("انستغرام", "IG", 0xFFC13584, "https://instagram.com/ohtmanTV"),
    Social("يوتيوب", "▶", 0xFFE53935, "https://youtube.com/@ohtmanTV"),
    Social("X", "X", 0xFF2A2A33, "https://x.com/ohtmanTV"),
)

// 🔐 رمز دخول الأدمن - غيّره قبل النشر
const val ADMIN_PIN = "1234"

// ☁️ إعدادات المزامنة مع GitHub (تأكد أن اسم المستخدم والمستودع صحيحان)
const val GH_REPO = "othmanetech475-tech/OhtmanTV"
const val GH_BRANCH = "main"
const val RAW_BASE = "https://raw.githubusercontent.com/$GH_REPO/$GH_BRANCH"
