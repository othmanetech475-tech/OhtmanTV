package com.ohtman.tv

data class Channel(val id: String, val name: String, val url: String, val emoji: String, val desc: String, val color: Long)
data class Section(val title: String, val icon: String, val channels: List<Channel>)
data class Match(val league: String, val home: String, val away: String, val day: String, val time: String, val live: Boolean, val channelId: String?, val score: String? = null, val finished: Boolean = false, val homeCrest: String? = null, val awayCrest: String? = null)

// ⚠️ بدّل الروابط التجريبية بروابط قنواتك (m3u8 / mpd)


val sections = listOf(
    Section("الأخبار", "📰", emptyList()),
    Section("الرياضة", "⚽", emptyList()),
    Section("الأفلام", "🎬", emptyList()),
    Section("الأطفال", "🧸", emptyList()),
)

// 📺 ربط الدوريات بالقنوات الناقلة (اسم الدوري كما يأتي من الـ API ← معرّف القناة)
// مثال: "Premier League" to "alarabiya"  (المعرّف id للقناة في قسم الأدمن)
val leagueChannels = mapOf<String, String>()

data class Social(val label: String, val glyph: String, val color: Long, val url: String)

// ⚠️ بدّل الروابط بحساباتك الحقيقية
val socials = listOf(
    Social("تيليجرام", "✈", 0xFF229ED9, "https://t.me/ohtmanTV"),
    Social("واتساب", "W", 0xFF25D366, "https://wa.me/0000000000"),
    Social("فيسبوك", "f", 0xFF1877F2, "https://facebook.com/ohtmanTV"),
    Social("انستغرام", "IG", 0xFFC13584, "https://instagram.com/ohtmanTV"),
    Social("يوتيوب", "▶", 0xFFE53935, "https://youtube.com/@ohtmanTV"),
    Social("X", "X", 0xFF2A2A33, "https://x.com/ohtmanTV"),
)

// 🔐 بصمة SHA-256 لكلمة سر الأدمن (كلمة السر نفسها غير مخزّنة في التطبيق)
const val ADMIN_HASH = "88360304feda3e22afbdc8d4fab5d0691a95ee38c184ae8a091043245d87a9ec"

// ☁️ إعدادات المزامنة مع GitHub (تأكد أن اسم المستخدم والمستودع صحيحان)
const val GH_REPO = "othmanetech475-tech/OhtmanTV"
const val GH_BRANCH = "main"
const val RAW_BASE = "https://raw.githubusercontent.com/$GH_REPO/$GH_BRANCH"
