@file:OptIn(androidx.media3.common.util.UnstableApi::class)
package com.ohtman.tv

import android.app.Activity
import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

val Gold = Color(0xFFF5C451)
val Bg = Color(0xFF0B0E17)
val CardBg = Color(0xFF151A28)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    var tab by remember { mutableStateOf(0) }
    var current by remember { mutableStateOf<Channel?>(null) }
    val all = sections.flatMap { it.channels }
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Bg, surface = CardBg)) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Box(Modifier.fillMaxSize().background(Bg)) {
                val c = current
                if (c != null) {
                    PlayerScreen(c, onBack = { current = null }, onPick = { current = it })
                } else {
                    Scaffold(containerColor = Bg, bottomBar = {
                        NavigationBar(containerColor = CardBg) {
                            listOf("🏠" to "الرئيسية", "📅" to "المباريات").forEachIndexed { i, (ic, label) ->
                                NavigationBarItem(selected = tab == i, onClick = { tab = i },
                                    icon = { Text(ic, fontSize = 20.sp) }, label = { Text(label) },
                                    colors = NavigationBarItemDefaults.colors(indicatorColor = Gold.copy(alpha = .2f), selectedTextColor = Gold))
                            }
                        }
                    }) { pad ->
                        if (tab == 0) Home(pad) { current = it }
                        else Matches(pad) { id -> current = all.firstOrNull { it.id == id } }
                    }
                }
            }
        }
    }
}

@Composable
fun Logo() {
    Row(Modifier.padding(20.dp, 24.dp, 20.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Gold), contentAlignment = Alignment.Center) {
            Text("▶", color = Bg, fontSize = 18.sp)
        }
        Spacer(Modifier.width(10.dp))
        Text("ohtman", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        Text("TV", color = Gold, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun Home(pad: PaddingValues, onPlay: (Channel) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad) {
        item { Logo() }
        item {  // Hero
            Box(Modifier.padding(16.dp).fillMaxWidth().height(170.dp).clip(RoundedCornerShape(24.dp))
                .background(Brush.linearGradient(listOf(Color(0xFFB71C1C), Color(0xFF2A0A0A))))
                .clickable { onPlay(alArabiya) }.padding(20.dp)) {
                Column(Modifier.align(Alignment.BottomStart)) {
                    Text("🔴 بث مباشر", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("قناة العربية", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    Text("اضغط للمشاهدة الآن", color = Color.White.copy(.7f), fontSize = 13.sp)
                }
                Text("📰", fontSize = 70.sp, modifier = Modifier.align(Alignment.TopEnd))
            }
        }
        sections.forEach { s ->
            item {
                Text("${s.icon}  ${s.title}", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(20.dp, 14.dp, 20.dp, 8.dp))
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(s.channels) { ch -> ChannelCard(ch) { onPlay(ch) } }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun ChannelCard(ch: Channel, onClick: () -> Unit) {
    Column(Modifier.width(150.dp).clip(RoundedCornerShape(20.dp)).background(CardBg).clickable(onClick = onClick)) {
        Box(Modifier.fillMaxWidth().height(95.dp)
            .background(Brush.linearGradient(listOf(Color(ch.color), Color(ch.color).copy(alpha = .35f)))),
            contentAlignment = Alignment.Center) { Text(ch.emoji, fontSize = 42.sp) }
        Column(Modifier.padding(12.dp)) {
            Text(ch.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
            Text("🔴 مباشر", color = Gold, fontSize = 11.sp)
        }
    }
}

@Composable
fun Matches(pad: PaddingValues, onWatch: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad) {
        item { Logo(); Text("📅  جدول المباريات", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(20.dp, 8.dp, 20.dp, 8.dp)) }
        items(matches) { m ->
            Column(Modifier.padding(16.dp, 6.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CardBg).padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(m.league, color = Gold, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    if (m.live) Text("🔴 مباشر", color = Color(0xFFFF5252), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    else Text("${m.day} • ${m.time}", color = Color.White.copy(.6f), fontSize = 12.sp)
                }
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(m.home, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    Text("VS", color = Gold, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 10.dp))
                    Text(m.away, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                }
                if (m.channelId != null) {
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { onWatch(m.channelId) }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Bg),
                        modifier = Modifier.fillMaxWidth()) { Text("▶  شاهد الآن", fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

@Composable
fun PlayerScreen(ch: Channel, onBack: () -> Unit, onPick: (Channel) -> Unit) {
    val ctx = LocalContext.current
    val act = ctx as Activity
    var full by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf(false) }
    var buffering by remember { mutableStateOf(true) }
    val player = remember { ExoPlayer.Builder(ctx).build().apply { playWhenReady = true } }

    LaunchedEffect(ch.id) {
        err = false
        player.setMediaItem(MediaItem.fromUri(ch.url)); player.prepare()
    }
    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) { buffering = state == Player.STATE_BUFFERING }
            override fun onPlayerError(error: PlaybackException) { err = true }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }
    DisposableEffect(full) {
        val ctl = WindowCompat.getInsetsController(act.window, act.window.decorView)
        if (full) {
            act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            ctl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            ctl.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            ctl.show(WindowInsetsCompat.Type.systemBars())
        }
        onDispose { act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED; ctl.show(WindowInsetsCompat.Type.systemBars()) }
    }
    BackHandler { if (full) full = false else onBack() }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Box(if (full) Modifier.fillMaxSize().background(Color.Black) else Modifier.fillMaxWidth().aspectRatio(16 / 9f).background(Color.Black)) {
            AndroidView(modifier = Modifier.fillMaxSize(), factory = { c ->
                PlayerView(c).apply {
                    this.player = player; keepScreenOn = true
                    setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                }
            })
            if (buffering && !err) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Gold)
            if (err) Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("تعذر تشغيل البث", color = Color.White)
                Button(onClick = { err = false; player.prepare() }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Bg)) { Text("إعادة المحاولة") }
            }
            Text(if (full) "⤡" else "⛶", color = Color.White, fontSize = 24.sp,
                modifier = Modifier.align(Alignment.TopStart).padding(12.dp).clip(RoundedCornerShape(10.dp))
                    .background(Color.Black.copy(.5f)).clickable { full = !full }.padding(8.dp, 2.dp))
            if (!full) Text("✕", color = Color.White, fontSize = 22.sp,
                modifier = Modifier.align(Alignment.TopEnd).padding(12.dp).clip(RoundedCornerShape(10.dp))
                    .background(Color.Black.copy(.5f)).clickable { onBack() }.padding(10.dp, 2.dp))
        }
        if (!full) {
            Column(Modifier.padding(20.dp)) {
                Text(ch.name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                Text("🔴 مباشر • ${ch.desc}", color = Gold, fontSize = 13.sp)
            }
            Text("قنوات أخرى", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp))
            LazyRow(contentPadding = PaddingValues(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(sections.flatMap { it.channels }.filter { it.id != ch.id }) { c -> ChannelCard(c) { onPick(c) } }
            }
        }
    }
}
