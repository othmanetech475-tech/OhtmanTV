@file:OptIn(androidx.media3.common.util.UnstableApi::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
package com.ohtman.tv

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import org.json.JSONArray
import org.json.JSONObject
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.media3.ui.AspectRatioFrameLayout
import kotlinx.coroutines.launch
import java.io.File
import android.content.Intent
import android.net.Uri
import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

val Gold = Color(0xFFF5B83D)
val Bg = Color(0xFF0A0A0F)
val Surf = Color(0xFF16161F)
val Live = Color(0xFFE53935)
val Muted = Color(0xFF9A9AA8)

fun grad(c: Long) = Brush.linearGradient(listOf(Color(c), Color(0xFF14141C)))
val featured = listOf(alArabiya) + sections[1].channels.take(1) + sections[2].channels.take(1)

val logoMap = mutableStateMapOf<String, ImageBitmap>()

fun loadLogos(ctx: Context) {
    ctx.filesDir.listFiles()?.filter { it.name.startsWith("logo_") }?.forEach { f ->
        BitmapFactory.decodeFile(f.path)?.let { logoMap[f.name.removePrefix("logo_").removeSuffix(".png")] = it.asImageBitmap() }
    }
}

fun saveLogo(ctx: Context, id: String, uri: android.net.Uri) {
    try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var sample = 1
        while (o.outWidth / sample > 1000) sample *= 2
        val bmp = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return
        File(ctx.filesDir, "logo_$id.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        logoMap[id] = bmp.asImageBitmap()
    } catch (_: Exception) {}
}

fun removeLogo(ctx: Context, id: String) {
    File(ctx.filesDir, "logo_$id.png").delete()
    logoMap.remove(id)
}

val customList = mutableStateListOf<Channel>()
val customSection = mutableStateMapOf<String, String>()
private val palette = listOf(0xFF1B5E20, 0xFF0D47A1, 0xFF4A148C, 0xFFE65100, 0xFFB71C1C, 0xFF00695C, 0xFF37474F)

fun allSections(): List<Section> {
    val base = sections.map { s -> s.copy(channels = s.channels + customList.filter { customSection[it.id] == s.title }) }
    val baseTitles = sections.map { it.title }.toSet()
    val extra = customList.mapNotNull { customSection[it.id] }.filter { it !in baseTitles }.distinct()
        .map { t -> Section(t, "📺", customList.filter { customSection[it.id] == t }) }
    return base + extra
}
fun allChannels() = allSections().flatMap { it.channels }

val logoUrls = HashMap<String, String>()
val dirtyLogos = HashSet<String>()
private fun prefs(ctx: Context) = ctx.getSharedPreferences("ohtman", 0)
fun ui(block: () -> Unit) { Handler(Looper.getMainLooper()).post { block() } }
fun toast(ctx: Context, m: String) = ui { Toast.makeText(ctx, m, Toast.LENGTH_LONG).show() }

fun catalogJson(): String {
    val arr = JSONArray()
    customList.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name).put("url", it.url).put("section", customSection[it.id] ?: "مضافة")) }
    val lg = JSONObject()
    logoUrls.forEach { (k, v) -> lg.put(k, v) }
    return JSONObject().put("channels", arr).put("logos", lg).toString()
}

fun persistCustom(ctx: Context) { prefs(ctx).edit().putString("custom", catalogJson()).apply() }

fun applyCatalog(txt: String) {
    val t = txt.trim()
    val o = if (t.startsWith("[")) JSONObject().put("channels", JSONArray(t)) else JSONObject(t)
    val arr = o.optJSONArray("channels") ?: JSONArray()
    customList.clear(); customSection.clear()
    for (i in 0 until arr.length()) {
        val c = arr.getJSONObject(i)
        val id = c.getString("id")
        customList.add(Channel(id, c.getString("name"), c.getString("url"), "⭐", "قناة مضافة", palette[Math.abs(id.hashCode()) % palette.size]))
        customSection[id] = c.getString("section")
    }
    logoUrls.clear()
    o.optJSONObject("logos")?.let { lg -> for (k in lg.keys()) logoUrls[k] = lg.getString(k) }
}

fun loadCustom(ctx: Context) {
    try { applyCatalog(prefs(ctx).getString("custom", "{}") ?: "{}") } catch (_: Exception) {}
}

// ⬇️ جلب القنوات من GitHub (يعمل عند كل تشغيل لكل المستخدمين)
fun syncCatalog(ctx: Context) {
    Thread {
        try {
            val c = URL("$RAW_BASE/channels.json?t=${System.currentTimeMillis()}").openConnection() as HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 8000
            if (c.responseCode == 200) {
                val txt = c.inputStream.bufferedReader().readText()
                ui { try { applyCatalog(txt); persistCustom(ctx) } catch (_: Exception) {} }
                val logos = JSONObject(txt).optJSONObject("logos")
                val remoteIds = HashSet<String>()
                if (logos != null) for (id in logos.keys()) {
                    remoteIds.add(id)
                    val u = logos.getString(id)
                    if (prefs(ctx).getString("lu_$id", "") != u) {
                        val bytes = URL(u).openStream().use { it.readBytes() }
                        File(ctx.filesDir, "logo_$id.png").writeBytes(bytes)
                        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        if (bmp != null) ui { logoMap[id] = bmp.asImageBitmap() }
                        prefs(ctx).edit().putString("lu_$id", u).apply()
                    }
                }
                prefs(ctx).all.keys.filter { it.startsWith("lu_") }.map { it.removePrefix("lu_") }.filter { it !in remoteIds }.forEach { id ->
                    ui { removeLogo(ctx, id) }
                    prefs(ctx).edit().remove("lu_$id").apply()
                }
            }
        } catch (_: Exception) {}
    }.start()
}

// ⬆️ نشر التغييرات للجميع (للأدمن فقط)
private fun ghRequest(method: String, path: String, token: String, body: String? = null): Pair<Int, String> {
    val q = if (method == "GET") "?ref=$GH_BRANCH" else ""
    val c = URL("https://api.github.com/repos/$GH_REPO/contents/$path$q").openConnection() as HttpURLConnection
    c.requestMethod = method
    c.connectTimeout = 15000; c.readTimeout = 30000
    c.setRequestProperty("Authorization", "Bearer $token")
    c.setRequestProperty("Accept", "application/vnd.github+json")
    c.setRequestProperty("User-Agent", "ohtmanTV")
    if (body != null) {
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toByteArray()) }
    }
    val code = c.responseCode
    val text = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
    return code to text
}

private fun ghPut(path: String, bytes: ByteArray, msg: String, token: String): Boolean {
    val (gc, gt) = ghRequest("GET", path, token)
    val body = JSONObject().put("message", msg).put("content", Base64.encodeToString(bytes, Base64.NO_WRAP)).put("branch", GH_BRANCH)
    if (gc == 200) body.put("sha", JSONObject(gt).getString("sha"))
    val (pc, _) = ghRequest("PUT", path, token, body.toString())
    return pc == 200 || pc == 201
}

fun publish(ctx: Context) {
    val token = prefs(ctx).getString("gh_token", "") ?: ""
    if (token.isBlank()) { toast(ctx, "أدخل GitHub Token من إعدادات الأدمن أولاً"); return }
    persistCustom(ctx)
    toast(ctx, "جارٍ النشر للجميع...")
    Thread {
        try {
            val now = System.currentTimeMillis()
            for (id in dirtyLogos.toList()) {
                val f = File(ctx.filesDir, "logo_$id.png")
                if (f.exists()) {
                    if (!ghPut("logos/$id.png", f.readBytes(), "logo $id", token)) throw Exception("رفع الصورة")
                    logoUrls[id] = "$RAW_BASE/logos/$id.png?v=$now"
                }
                dirtyLogos.remove(id)
            }
            val ok = ghPut("channels.json", catalogJson().toByteArray(), "update channels", token)
            if (ok) persistCustom(ctx)
            toast(ctx, if (ok) "تم النشر للجميع ✓" else "فشل النشر - تحقق من التوكن")
        } catch (e: Exception) { toast(ctx, "فشل النشر: ${e.message}") }
    }.start()
}

fun adminRemoveLogo(ctx: Context, id: String) {
    removeLogo(ctx, id); logoUrls.remove(id); dirtyLogos.remove(id); publish(ctx)
}

fun addCustom(ctx: Context, id: String, name: String, url: String, section: String): Channel {
    val ch = Channel(id, name, url, "⭐", "قناة مضافة", palette[Math.abs(id.hashCode()) % palette.size])
    val i = customList.indexOfFirst { it.id == id }
    if (i >= 0) customList[i] = ch else customList.add(ch)
    customSection[id] = section
    persistCustom(ctx)
    return ch
}

fun deleteCustom(ctx: Context, id: String) {
    customList.removeAll { it.id == id }
    customSection.remove(id)
    removeLogo(ctx, id)
    logoUrls.remove(id); dirtyLogos.remove(id)
    publish(ctx)
}

val adminState = mutableStateOf(false)
fun setAdmin(ctx: Context, v: Boolean) {
    adminState.value = v
    ctx.getSharedPreferences("ohtman", 0).edit().putBoolean("admin", v).apply()
}

class Favs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("ohtman", 0)
    val ids = mutableStateListOf<String>().apply { addAll(sp.getStringSet("f", emptySet()) ?: emptySet()) }
    fun toggle(id: String) {
        if (id in ids) ids.remove(id) else ids.add(id)
        sp.edit().putStringSet("f", ids.toSet()).apply()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun Splash() {
    val a = remember { Animatable(0f) }
    val sc = remember { Animatable(.75f) }
    val b = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { sc.animateTo(1f, tween(1100, easing = FastOutSlowInEasing)) }
        a.animateTo(1f, tween(1000))
        b.animateTo(1f, tween(900))
    }
    Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF2B2108), Bg), radius = 1100f)), contentAlignment = Alignment.Center) {
        Box(Modifier.size(340.dp).graphicsLayer { alpha = a.value }
            .background(Brush.radialGradient(listOf(Gold.copy(alpha = .20f), Color.Transparent)), CircleShape))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.graphicsLayer { alpha = a.value; scaleX = sc.value; scaleY = sc.value }, verticalAlignment = Alignment.CenterVertically) {
                Text("ohtman", color = Color.White, fontSize = 46.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.width(8.dp))
                Text("TV", color = Bg, fontSize = 32.sp, fontWeight = FontWeight.Black,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFFFFE08A), Gold, Color(0xFFB8860B)))).padding(14.dp, 2.dp))
            }
            Spacer(Modifier.height(18.dp))
            Box(Modifier.graphicsLayer { alpha = b.value }.width(90.dp).height(3.dp).clip(CircleShape)
                .background(Brush.horizontalGradient(listOf(Color.Transparent, Gold, Color.Transparent))))
            Spacer(Modifier.height(18.dp))
            Text("مرحباً بك في عالم الفرجة", modifier = Modifier.graphicsLayer { alpha = b.value },
                style = TextStyle(brush = Brush.linearGradient(listOf(Color(0xFFFFE08A), Gold, Color(0xFFD4A017))),
                    fontSize = 24.sp, fontWeight = FontWeight.Bold))
            Spacer(Modifier.height(8.dp))
            Text("قنوات • مباريات • أفلام • بث مباشر", color = Muted, fontSize = 13.sp, modifier = Modifier.graphicsLayer { alpha = b.value })
        }
        CircularProgressIndicator(Modifier.align(Alignment.BottomCenter).padding(bottom = 56.dp).size(26.dp).graphicsLayer { alpha = b.value },
            color = Gold, strokeWidth = 2.dp)
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val favs = remember { Favs(ctx) }
    LaunchedEffect(Unit) { loadLogos(ctx); loadCustom(ctx); adminState.value = ctx.getSharedPreferences("ohtman", 0).getBoolean("admin", false); syncCatalog(ctx) }
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { delay(3600); splash = false }
    var tab by remember { mutableStateOf(0) }
    var current by remember { mutableStateOf<Channel?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var showAdmin by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Bg, surface = Surf)) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Crossfade(targetState = splash, animationSpec = tween(700), label = "splash") { showSplash ->
                if (showSplash) Splash() else Box(Modifier.fillMaxSize().background(Bg)) {
                    val c = current
                    if (showEditor) ChannelEditor(null) { showEditor = false }
                    if (showAdmin) AdminDialog { showAdmin = false }
                    if (c != null) {
                        PlayerScreen(c, favs, onBack = { current = null }, onPick = { current = it })
                    } else {
                        val play: (Channel) -> Unit = { current = it }
                        Scaffold(containerColor = Bg, topBar = { TopNav(tab, { showEditor = true }, { showAdmin = true }) { tab = it } }) { pad ->
                            when {
                                tab == 0 -> Home(pad, play)
                                tab == 1 -> Matches(pad) { id -> allChannels().firstOrNull { it.id == id }?.let(play) }
                                tab >= 2 -> allSections().getOrNull(tab - 2)?.let { CategoryScreen(pad, it, play) } ?: Home(pad, play)
                                tab == -1 -> Favorites(pad, favs, play)
                                else -> SearchScreen(pad, play)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Logo(onLong: () -> Unit = {}) {
    Row(Modifier.combinedClickable(onClick = {}, onLongClick = onLong).padding(20.dp, 8.dp, 20.dp, 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("ohtman", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.width(4.dp))
        Text("TV", color = Bg, fontSize = 17.sp, fontWeight = FontWeight.Black,
            modifier = Modifier.clip(RoundedCornerShape(7.dp)).background(Gold).padding(7.dp, 1.dp))
    }
}

@Composable
fun LiveBadge() {
    Row(Modifier.clip(RoundedCornerShape(6.dp)).background(Live).padding(7.dp, 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(6.dp).clip(CircleShape).background(Color.White))
        Spacer(Modifier.width(4.dp))
        Text("مباشر", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SectionTitle(t: String) {
    Row(Modifier.padding(20.dp, 22.dp, 20.dp, 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(4.dp, 18.dp).clip(CircleShape).background(Gold))
        Spacer(Modifier.width(8.dp))
        Text(t, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Chip(label: String, sel: Boolean, onClick: () -> Unit) {
    Text(label, color = if (sel) Bg else Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (sel) Gold else Surf).clickable(onClick = onClick).padding(18.dp, 9.dp))
}

@Composable
fun ChannelCard(ch: Channel, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.aspectRatio(16 / 10f).clip(RoundedCornerShape(16.dp)).background(grad(ch.color)).clickable(onClick = onClick)) {
        Text(ch.name.first().toString(), color = Color.White.copy(.1f), fontSize = 100.sp, fontWeight = FontWeight.Black,
            modifier = Modifier.align(Alignment.CenterStart).padding(start = 10.dp))
        logoMap[ch.id]?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        Box(Modifier.padding(8.dp).align(Alignment.TopStart)) { LiveBadge() }
        Box(Modifier.fillMaxWidth().align(Alignment.BottomCenter)
            .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.75f)))).padding(10.dp, 18.dp, 10.dp, 10.dp)) {
            Text(ch.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
        }
    }
}

fun LazyListScope.channelGrid(list: List<Channel>, onPlay: (Channel) -> Unit) {
    items(list.chunked(2)) { row ->
        Row(Modifier.padding(16.dp, 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            row.forEach { ch -> ChannelCard(ch, Modifier.weight(1f)) { onPlay(ch) } }
            if (row.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
fun Hero(list: List<Channel>, onPlay: (Channel) -> Unit) {
    val st = rememberPagerState { list.size }
    LaunchedEffect(Unit) { while (true) { delay(4500); st.animateScrollToPage((st.currentPage + 1) % list.size) } }
    Column {
        HorizontalPager(st, contentPadding = PaddingValues(horizontal = 16.dp), pageSpacing = 12.dp) { i ->
            val ch = list[i]
            Box(Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(24.dp)).background(grad(ch.color)).clickable { onPlay(ch) }) {
                Text(ch.name.first().toString(), color = Color.White.copy(.1f), fontSize = 190.sp, fontWeight = FontWeight.Black,
                    modifier = Modifier.align(Alignment.CenterEnd).padding(end = 16.dp))
                logoMap[ch.id]?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.8f)))))
                Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
                    LiveBadge()
                    Spacer(Modifier.height(8.dp))
                    Text(ch.name, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    Text(ch.desc, color = Color.White.copy(.7f), fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.clip(RoundedCornerShape(50)).background(Gold).padding(16.dp, 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.PlayArrow, null, tint = Bg, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("مشاهدة الآن", color = Bg, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.Center) {
            repeat(list.size) { i ->
                Box(Modifier.padding(3.dp).height(6.dp).width(if (i == st.currentPage) 18.dp else 6.dp).clip(CircleShape)
                    .background(if (i == st.currentPage) Gold else Color.White.copy(.25f)))
            }
        }
    }
}

@Composable
fun TopNav(tab: Int, onAdd: () -> Unit, onSecret: () -> Unit, onTab: (Int) -> Unit) {
    val labels = listOf("الرئيسية", "المباريات") + allSections().map { it.title }
    Column(Modifier.fillMaxWidth().background(Bg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Logo(onSecret)
                if (adminState.value) Text("ADMIN", color = Bg, fontSize = 9.sp, fontWeight = FontWeight.Black,
                    modifier = Modifier.clip(RoundedCornerShape(5.dp)).background(Gold).padding(5.dp, 1.dp))
            }
            if (adminState.value) IconButton(onClick = onAdd) { Icon(Icons.Filled.Add, null, tint = Gold) }
            IconButton(onClick = { onTab(-2) }) { Icon(Icons.Filled.Search, null, tint = if (tab == -2) Gold else Color.White) }
            IconButton(onClick = { onTab(-1) }) { Icon(Icons.Filled.Favorite, null, tint = if (tab == -1) Gold else Color.White) }
            Spacer(Modifier.width(8.dp))
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp)) {
            labels.forEachIndexed { i, l ->
                Column(Modifier.clickable { onTab(i) }.padding(14.dp, 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(l, color = if (tab == i) Gold else Muted, fontSize = 15.sp, fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Medium)
                    Spacer(Modifier.height(6.dp))
                    Box(Modifier.height(3.dp).width(24.dp).clip(CircleShape).background(if (tab == i) Gold else Color.Transparent))
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(.07f)))
    }
}

@Composable
fun CategoryScreen(pad: PaddingValues, s: Section, onPlay: (Channel) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad) {
        item { SectionTitle(s.title) }
        channelGrid(s.channels, onPlay)
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun Home(pad: PaddingValues, onPlay: (Channel) -> Unit) {
    val secs = allSections()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad) {
        item { Spacer(Modifier.height(12.dp)); Hero(featured, onPlay) }
        item {
            SectionTitle("مباريات اليوم")
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(matches.filter { it.day == "اليوم" }) { m ->
                    MatchCard(m, Modifier.width(300.dp)) { id -> allChannels().firstOrNull { it.id == id }?.let(onPlay) }
                }
            }
        }
        secs.forEach { sec ->
            item {
                SectionTitle(sec.title)
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(sec.channels) { ch -> ChannelCard(ch, Modifier.width(180.dp)) { onPlay(ch) } }
                }
            }
        }
        item { SocialRow() }
    }
}

@Composable
fun Team(name: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(52.dp).clip(CircleShape).background(Color(0xFF23232F)), contentAlignment = Alignment.Center) {
            Text(name.first().toString(), color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(6.dp))
        Text(name, color = Color.White, fontSize = 13.sp, textAlign = TextAlign.Center, maxLines = 1)
    }
}

@Composable
fun MatchCard(m: Match, modifier: Modifier = Modifier, onWatch: (String) -> Unit) {
    Column(modifier.clip(RoundedCornerShape(20.dp)).background(Surf).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(m.league, color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
            if (m.live) LiveBadge()
        }
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Team(m.home, Modifier.weight(1f))
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(64.dp)) {
                Text(if (m.live) "VS" else m.time, color = if (m.live) Live else Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                Text(m.day, color = Muted, fontSize = 11.sp)
            }
            Team(m.away, Modifier.weight(1f))
        }
        if (m.channelId != null) {
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (m.live) Gold else Color(0xFF23232F))
                .clickable { onWatch(m.channelId) }.padding(10.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.PlayArrow, null, tint = if (m.live) Bg else Gold, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(4.dp))
                Text("مشاهدة البث", color = if (m.live) Bg else Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun Matches(pad: PaddingValues, onWatch: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad) {
        matches.groupBy { it.day }.forEach { (day, list) ->
            item { SectionTitle(day) }
            items(list) { m -> MatchCard(m, Modifier.padding(16.dp, 6.dp).fillMaxWidth(), onWatch) }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun Favorites(pad: PaddingValues, favs: Favs, onPlay: (Channel) -> Unit) {
    val list = allChannels().filter { it.id in favs.ids }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad) {
        item { SectionTitle("المفضلة") }
        if (list.isEmpty()) item {
            Column(Modifier.fillMaxWidth().padding(40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.FavoriteBorder, null, tint = Muted, modifier = Modifier.size(56.dp))
                Spacer(Modifier.height(12.dp))
                Text("لا توجد قنوات مفضلة بعد", color = Color.White, fontWeight = FontWeight.Bold)
                Text("اضغط على القلب داخل أي قناة لإضافتها", color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
            }
        } else channelGrid(list, onPlay)
    }
}

@Composable
fun SearchScreen(pad: PaddingValues, onPlay: (Channel) -> Unit) {
    var q by remember { mutableStateOf("") }
    val res = if (q.isBlank()) allChannels() else allChannels().filter { it.name.contains(q.trim(), true) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad) {
        item {
            TextField(value = q, onValueChange = { q = it }, singleLine = true, shape = RoundedCornerShape(16.dp),
                placeholder = { Text("ابحث عن قناة...") }, leadingIcon = { Icon(Icons.Filled.Search, null) },
                colors = TextFieldDefaults.colors(focusedContainerColor = Surf, unfocusedContainerColor = Surf,
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, cursorColor = Gold),
                modifier = Modifier.fillMaxWidth().padding(16.dp, 4.dp, 16.dp, 12.dp))
        }
        channelGrid(res, onPlay)
    }
}

@Composable
fun RoundBtn(modifier: Modifier, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(modifier.padding(12.dp).size(40.dp).clip(CircleShape).background(Color.Black.copy(.55f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center) { content() }
}

@Composable
fun Pill(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(50)).background(Surf).clickable(onClick = onClick).padding(14.dp, 9.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Gold, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun PlayerScreen(ch: Channel, favs: Favs, onBack: () -> Unit, onPick: (Channel) -> Unit) {
    val ctx = LocalContext.current
    val act = ctx as Activity
    var full by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf(false) }
    var buffering by remember { mutableStateOf(true) }
    var mode by remember { mutableStateOf(0) }
    var editing by remember { mutableStateOf(false) }
    var confirmDel by remember { mutableStateOf(false) }
    val modes = remember {
        listOf("ملاءمة" to AspectRatioFrameLayout.RESIZE_MODE_FIT, "تكبير" to AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
            "تمديد" to AspectRatioFrameLayout.RESIZE_MODE_FILL, "عرض" to AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH,
            "طول" to AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT)
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) { saveLogo(ctx, ch.id, uri); dirtyLogos.add(ch.id); publish(ctx) } }
    val player = remember { ExoPlayer.Builder(ctx).build().apply { playWhenReady = true } }

    LaunchedEffect(ch.id, ch.url) { err = false; player.setMediaItem(MediaItem.fromUri(ch.url)); player.prepare() }
    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) { buffering = state == Player.STATE_BUFFERING }
            override fun onPlayerError(error: PlaybackException) { err = true }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }
    DisposableEffect(full) {
        val ctl = WindowCompat.getInsetsController(act.window, act.window.decorView)
        if (full) {
            act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            ctl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            ctl.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            ctl.show(WindowInsetsCompat.Type.systemBars())
        }
        onDispose { act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED; ctl.show(WindowInsetsCompat.Type.systemBars()) }
    }
    BackHandler { if (full) full = false else onBack() }
    if (editing) ChannelEditor(allChannels().firstOrNull { it.id == ch.id }) { c -> editing = false; if (c != null) onPick(c) }
    if (confirmDel) AlertDialog(onDismissRequest = { confirmDel = false }, containerColor = Surf,
        title = { Text("حذف القناة؟", color = Color.White, fontWeight = FontWeight.Bold) },
        text = { Text("سيتم حذف ${ch.name} نهائياً", color = Muted) },
        confirmButton = { TextButton(onClick = { deleteCustom(ctx, ch.id); onBack() }) { Text("حذف", color = Live) } },
        dismissButton = { TextButton(onClick = { confirmDel = false }) { Text("إلغاء", color = Muted) } })

    Column(Modifier.fillMaxSize().background(Bg)) {
        Box(if (full) Modifier.fillMaxSize().background(Color.Black) else Modifier.fillMaxWidth().aspectRatio(16 / 9f).background(Color.Black)) {
            AndroidView(modifier = Modifier.fillMaxSize(), factory = { c ->
                PlayerView(c).apply { this.player = player; keepScreenOn = true; setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING) }
            }, update = { it.resizeMode = modes[mode].second })
            if (buffering && !err) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Gold)
            if (err) Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("تعذر تشغيل البث", color = Color.White)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { err = false; player.prepare() }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Bg)) { Text("إعادة المحاولة") }
            }
            RoundBtn(Modifier.align(Alignment.TopStart), { if (full) full = false else onBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
            }
            Row(Modifier.align(Alignment.TopCenter).padding(top = 14.dp).clip(RoundedCornerShape(50)).background(Color.Black.copy(.55f))
                .clickable { mode = (mode + 1) % modes.size }.padding(14.dp, 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("⤢", color = Gold, fontSize = 16.sp)
                Spacer(Modifier.width(6.dp))
                Text("الحجم: ${modes[mode].first}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
            RoundBtn(Modifier.align(Alignment.TopEnd), { full = !full }) {
                Text(if (full) "⤡" else "⛶", color = Color.White, fontSize = 20.sp)
            }
        }
        if (!full) {
            val isFav = ch.id in favs.ids
            val others = allChannels().filter { it.id != ch.id }
            Column(Modifier.padding(20.dp)) {
                LiveBadge()
                Spacer(Modifier.height(10.dp))
                Text(ch.name, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                Text(ch.desc, color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Pill(if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, if (isFav) "في المفضلة" else "أضف للمفضلة") { favs.toggle(ch.id) }
                    if (adminState.value) Pill(Icons.Filled.Add, "رفع صورة للقناة") { picker.launch("image/*") }
                    if (adminState.value && logoMap[ch.id] != null) {
                        Box(Modifier.size(38.dp).clip(CircleShape).background(Surf).clickable { adminRemoveLogo(ctx, ch.id) }, contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Delete, null, tint = Live, modifier = Modifier.size(18.dp))
                        }
                    }
                }
                if (adminState.value && ch.id in customSection) {
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill(Icons.Filled.Create, "تعديل القناة") { editing = true }
                        Pill(Icons.Filled.Delete, "حذف القناة") { confirmDel = true }
                    }
                }
            }
            SectionTitle("قنوات أخرى")
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(others) { c -> ChannelCard(c, Modifier.width(170.dp)) { onPick(c) } }
            }
        }
    }
}

@Composable
fun SocialRow() {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxWidth().padding(20.dp, 28.dp, 20.dp, 32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("تابعنا على", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            socials.forEach { s ->
                Box(Modifier.size(42.dp).clip(CircleShape).background(Color(s.color)).clickable {
                    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(s.url))) } catch (_: Exception) {}
                }, contentAlignment = Alignment.Center) {
                    Text(s.glyph, color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("ohtmanTV © 2026", color = Muted.copy(.6f), fontSize = 11.sp)
    }
}

@Composable
fun Field(v: String, onChange: (String) -> Unit, label: String, uri: Boolean = false, pass: Boolean = false, secret: Boolean = false) {
    OutlinedTextField(value = v, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = if (pass) KeyboardType.NumberPassword else if (secret) KeyboardType.Password else if (uri) KeyboardType.Uri else KeyboardType.Text),
        visualTransformation = if (pass || secret) PasswordVisualTransformation() else VisualTransformation.None,
        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Gold, unfocusedBorderColor = Color(0xFF3A3A48),
            focusedLabelColor = Gold, unfocusedLabelColor = Muted, cursorColor = Gold,
            focusedTextColor = Color.White, unfocusedTextColor = Color.White))
}

@Composable
fun ChannelEditor(existing: Channel?, onDone: (Channel?) -> Unit) {
    val ctx = LocalContext.current
    val id = remember { existing?.id ?: "c_${System.currentTimeMillis()}" }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var url by remember { mutableStateOf(existing?.url ?: "") }
    val titles = allSections().map { it.title }
    var sec by remember { mutableStateOf(existing?.let { customSection[it.id] } ?: titles.first()) }
    var newSec by remember { mutableStateOf("") }
    var isNew by remember { mutableStateOf(false) }
    var picked by remember { mutableStateOf<Uri?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { if (it != null) picked = it }
    val ok = name.isNotBlank() && url.trim().startsWith("http") && (!isNew || newSec.isNotBlank())
    AlertDialog(onDismissRequest = { onDone(null) }, containerColor = Surf,
        title = { Text(if (existing == null) "إضافة قناة جديدة" else "تعديل القناة", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Field(name, { name = it }, "اسم القناة")
                Field(url, { url = it }, "رابط البث (m3u8 / mpd)", uri = true)
                Text("القسم", color = Muted, fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    titles.forEach { t -> Chip(t, !isNew && sec == t) { isNew = false; sec = t } }
                    Chip("+ قسم جديد", isNew) { isNew = true }
                }
                if (isNew) Field(newSec, { newSec = it }, "اسم القسم الجديد")
                Pill(Icons.Filled.Add, if (picked != null || logoMap[id] != null) "تغيير الصورة ✓" else "اختيار صورة (اختياري)") { picker.launch("image/*") }
            }
        },
        confirmButton = {
            TextButton(enabled = ok, onClick = {
                val ch = addCustom(ctx, id, name.trim(), url.trim(), if (isNew) newSec.trim() else sec)
                picked?.let { saveLogo(ctx, id, it); dirtyLogos.add(id) }
                publish(ctx)
                onDone(ch)
            }) { Text("حفظ", color = if (ok) Gold else Muted, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = { onDone(null) }) { Text("إلغاء", color = Muted) } })
}

@Composable
fun AdminDialog(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    var token by remember { mutableStateOf(prefs(ctx).getString("gh_token", "") ?: "") }
    if (adminState.value) {
        AlertDialog(onDismissRequest = onDone, containerColor = Surf,
            title = { Text("وضع الأدمن مفعّل", color = Gold, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("أي تغيير تحفظه يُنشر تلقائياً لكل المستخدمين.", color = Muted, fontSize = 13.sp)
                    Field(token, { token = it }, "GitHub Token (للنشر)", secret = true)
                    Text(if (token.isBlank()) "⚠️ لم يُحفظ التوكن بعد" else "✓ التوكن محفوظ", color = if (token.isBlank()) Live else Gold, fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = { prefs(ctx).edit().putString("gh_token", token.trim()).apply(); syncCatalog(ctx); onDone() }) { Text("حفظ ومزامنة", color = Gold, fontWeight = FontWeight.Bold) } },
            dismissButton = {
                Row {
                    TextButton(onClick = { setAdmin(ctx, false); onDone() }) { Text("خروج", color = Live) }
                    TextButton(onClick = onDone) { Text("إغلاق", color = Muted) }
                }
            })
    } else {
        AlertDialog(onDismissRequest = onDone, containerColor = Surf,
            title = { Text("دخول الأدمن", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Field(pin, { pin = it; wrong = false }, "الرمز السري", pass = true)
                    if (wrong) Text("الرمز غير صحيح", color = Live, fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = { if (pin == ADMIN_PIN) { setAdmin(ctx, true); onDone() } else wrong = true }) { Text("دخول", color = Gold, fontWeight = FontWeight.Bold) } },
            dismissButton = { TextButton(onClick = onDone) { Text("إلغاء", color = Muted) } })
    }
}
