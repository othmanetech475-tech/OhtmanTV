@file:OptIn(androidx.media3.common.util.UnstableApi::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
package com.ohtman.tv

import android.app.Activity
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.zIndex
import android.net.ConnectivityManager
import android.net.Network
import android.provider.Settings
import androidx.compose.ui.graphics.StrokeJoin
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import android.app.PictureInPictureParams
import android.os.Build
import android.util.Rational
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntOffset
import androidx.core.app.PictureInPictureModeChangedInfo
import androidx.core.util.Consumer
import androidx.media3.common.C
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import coil.ImageLoader
import coil.compose.SubcomposeAsyncImage
import coil.decode.SvgDecoder
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import org.json.JSONArray
import org.json.JSONObject
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.media3.ui.AspectRatioFrameLayout
import kotlinx.coroutines.launch
import java.io.File
import android.content.Intent
import android.net.Uri
import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

val Gold = Color(0xFFF5B83D)
val Bg = Color(0xFF0A0A0F)
val Surf = Color(0xFF16161F)
val Live = Color(0xFFE53935)
val Muted = Color(0xFF9A9AA8)

fun grad(c: Long) = Brush.linearGradient(listOf(Color(c), Color(0xFF14141C)))

val logoMap = mutableStateMapOf<String, ImageBitmap>()

fun loadLogos(ctx: Context) {
    ctx.filesDir.listFiles()?.filter { it.name.startsWith("logo_") }?.forEach { f ->
        sampled(f.readBytes(), if (f.name.startsWith("logo_banner")) 1080 else 480)?.let { logoMap[f.name.removePrefix("logo_").removeSuffix(".png")] = it.asImageBitmap() }
    }
}

fun saveLogo(ctx: Context, id: String, uri: android.net.Uri) {
    try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var sample = 1
        while (o.outWidth / sample > 1000) sample *= 2
        val bmp = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return
        File(ctx.filesDir, "logo_$id.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        logoMap[id] = bmp.asImageBitmap()
    } catch (_: Exception) {}
}

fun removeLogo(ctx: Context, id: String) {
    File(ctx.filesDir, "logo_$id.png").delete()
    logoMap.remove(id)
}

lateinit var imgLoader: ImageLoader
val leagueMap = mutableStateMapOf<String, String>()
val socialUrls = mutableStateMapOf<String, String>()
val hiddenSections = mutableStateListOf<String>()
val customList = mutableStateListOf<Channel>()
val customSection = mutableStateMapOf<String, String>()
private val palette = listOf(0xFF1B5E20, 0xFF0D47A1, 0xFF4A148C, 0xFFE65100, 0xFFB71C1C, 0xFF00695C, 0xFF37474F)

fun allSections(): List<Section> {
    val base = sections.filter { it.title !in hiddenSections }.map { s -> s.copy(channels = s.channels + customList.filter { customSection[it.id] == s.title }) }
    val baseTitles = sections.filter { it.title !in hiddenSections }.map { it.title }.toSet()
    val extra = customList.mapNotNull { customSection[it.id] }.filter { it !in baseTitles }.distinct()
        .map { t -> Section(t, "📺", customList.filter { customSection[it.id] == t }) }
    return base + extra
}
fun allChannels() = allSections().flatMap { it.channels }

val logoUrls = HashMap<String, String>()
val dirtyLogos = HashSet<String>()
private fun prefs(ctx: Context) = ctx.getSharedPreferences("ohtman", 0)
fun ui(block: () -> Unit) { Handler(Looper.getMainLooper()).post { block() } }
fun toast(ctx: Context, m: String) = ui { Toast.makeText(ctx, m, Toast.LENGTH_LONG).show() }

fun catalogJson(): String {
    val arr = JSONArray()
    customList.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name).put("url", it.url).put("section", customSection[it.id] ?: "مضافة")) }
    val lg = JSONObject()
    logoUrls.forEach { (k, v) -> lg.put(k, v) }
    val lm = JSONObject()
    leagueMap.forEach { (k, v) -> lm.put(k, v) }
    val sj = JSONObject()
    socialUrls.forEach { (k, v) -> sj.put(k, v) }
    return JSONObject().put("channels", arr).put("logos", lg).put("leagues", lm).put("hidden", JSONArray(hiddenSections.toList())).put("socials", sj).toString()
}

fun persistCustom(ctx: Context) { prefs(ctx).edit().putString("custom", catalogJson()).apply() }

fun applyCatalog(txt: String) {
    val t = txt.trim()
    val o = if (t.startsWith("[")) JSONObject().put("channels", JSONArray(t)) else JSONObject(t)
    val arr = o.optJSONArray("channels") ?: JSONArray()
    customList.clear(); customSection.clear()
    for (i in 0 until arr.length()) {
        val c = arr.getJSONObject(i)
        val id = c.getString("id")
        customList.add(Channel(id, c.getString("name"), c.getString("url"), "⭐", "قناة مضافة", palette[Math.abs(id.hashCode()) % palette.size]))
        customSection[id] = c.getString("section")
    }
    logoUrls.clear()
    o.optJSONObject("logos")?.let { lg -> for (k in lg.keys()) logoUrls[k] = lg.getString(k) }
    leagueMap.clear()
    o.optJSONObject("leagues")?.let { lm -> for (k in lm.keys()) leagueMap[k] = lm.getString(k) }
    socialUrls.clear()
    o.optJSONObject("socials")?.let { so -> for (k in so.keys()) socialUrls[k] = so.getString(k) }
    hiddenSections.clear()
    o.optJSONArray("hidden")?.let { ha -> for (i in 0 until ha.length()) hiddenSections.add(ha.getString(i)) }
}

fun loadCustom(ctx: Context) {
    try { applyCatalog(prefs(ctx).getString("custom", "{}") ?: "{}") } catch (_: Exception) {}
}

// ⬇️ جلب القنوات من GitHub (يعمل عند كل تشغيل لكل المستخدمين)
fun syncCatalog(ctx: Context) {
    Thread {
        try {
            val c = URL("$RAW_BASE/channels.json?t=${System.currentTimeMillis()}").openConnection() as HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 8000
            if (c.responseCode == 200) {
                val txt = c.inputStream.bufferedReader().readText()
                ui { try { applyCatalog(txt); persistCustom(ctx) } catch (_: Exception) {} }
                val logos = JSONObject(txt).optJSONObject("logos")
                val remoteIds = HashSet<String>()
                if (logos != null) for (id in logos.keys()) {
                    remoteIds.add(id)
                    val u = logos.getString(id)
                    if (prefs(ctx).getString("lu_$id", "") != u) try {
                        val bytes = URL(u).openStream().use { it.readBytes() }
                        File(ctx.filesDir, "logo_$id.png").writeBytes(bytes)
                        val bmp = sampled(bytes, if (id.startsWith("banner")) 1080 else 480)
                        if (bmp != null) ui { logoMap[id] = bmp.asImageBitmap() }
                        prefs(ctx).edit().putString("lu_$id", u).apply()
                    } catch (_: Exception) {}
                }
                prefs(ctx).all.keys.filter { it.startsWith("lu_") }.map { it.removePrefix("lu_") }.filter { it !in remoteIds }.forEach { id ->
                    ui { removeLogo(ctx, id) }
                    prefs(ctx).edit().remove("lu_$id").apply()
                }
            }
        } catch (_: Exception) {}
    }.start()
}

// ⬆️ نشر التغييرات للجميع (للأدمن فقط)
private fun ghRequest(method: String, path: String, token: String, body: String? = null): Pair<Int, String> {
    val q = if (method == "GET") "?ref=$GH_BRANCH" else ""
    val c = URL("https://api.github.com/repos/$GH_REPO/contents/$path$q").openConnection() as HttpURLConnection
    c.requestMethod = method
    c.connectTimeout = 15000; c.readTimeout = 30000
    c.setRequestProperty("Authorization", "Bearer $token")
    c.setRequestProperty("Accept", "application/vnd.github+json")
    c.setRequestProperty("User-Agent", "ohtmanTV")
    if (body != null) {
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toByteArray()) }
    }
    val code = c.responseCode
    val text = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
    return code to text
}

private fun ghPut(path: String, bytes: ByteArray, msg: String, token: String): Boolean {
    val (gc, gt) = ghRequest("GET", path, token)
    val body = JSONObject().put("message", msg).put("content", Base64.encodeToString(bytes, Base64.NO_WRAP)).put("branch", GH_BRANCH)
    if (gc == 200) body.put("sha", JSONObject(gt).getString("sha"))
    val (pc, _) = ghRequest("PUT", path, token, body.toString())
    return pc == 200 || pc == 201
}

fun publish(ctx: Context) {
    val token = prefs(ctx).getString("gh_token", "") ?: ""
    if (token.isBlank()) { toast(ctx, "أدخل GitHub Token من إعدادات الأدمن أولاً"); return }
    persistCustom(ctx)
    toast(ctx, "جارٍ النشر للجميع...")
    Thread {
        try {
            val now = System.currentTimeMillis()
            for (id in dirtyLogos.toList()) {
                val f = File(ctx.filesDir, "logo_$id.png")
                if (f.exists()) {
                    if (!ghPut("logos/$id.png", f.readBytes(), "logo $id", token)) throw Exception("رفع الصورة")
                    logoUrls[id] = "$RAW_BASE/logos/$id.png?v=$now"
                }
                dirtyLogos.remove(id)
            }
            val ok = ghPut("channels.json", catalogJson().toByteArray(), "update channels", token)
            if (ok) persistCustom(ctx)
            toast(ctx, if (ok) "تم النشر للجميع ✓" else "فشل النشر - تحقق من التوكن")
        } catch (e: Exception) { toast(ctx, "فشل النشر: ${e.message}") }
    }.start()
}

fun deleteSection(ctx: Context, title: String) {
    customList.filter { customSection[it.id] == title }.map { it.id }.forEach { id ->
        customList.removeAll { c -> c.id == id }
        customSection.remove(id); logoUrls.remove(id); dirtyLogos.remove(id); removeLogo(ctx, id)
    }
    if (sections.any { it.title == title } && title !in hiddenSections) hiddenSections.add(title)
    publish(ctx)
}

fun sha256(s: String): String = java.security.MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

fun adminRemoveLogo(ctx: Context, id: String) {
    removeLogo(ctx, id); logoUrls.remove(id); dirtyLogos.remove(id); publish(ctx)
}

fun addCustom(ctx: Context, id: String, name: String, url: String, section: String): Channel {
    val ch = Channel(id, name, url, "⭐", "قناة مضافة", palette[Math.abs(id.hashCode()) % palette.size])
    val i = customList.indexOfFirst { it.id == id }
    if (i >= 0) customList[i] = ch else customList.add(ch)
    customSection[id] = section
    persistCustom(ctx)
    return ch
}

fun deleteCustom(ctx: Context, id: String) {
    customList.removeAll { it.id == id }
    customSection.remove(id)
    removeLogo(ctx, id)
    logoUrls.remove(id); dirtyLogos.remove(id)
    publish(ctx)
}

val adminState = mutableStateOf(false)
fun setAdmin(ctx: Context, v: Boolean) {
    adminState.value = v
    ctx.getSharedPreferences("ohtman", 0).edit().putBoolean("admin", v).apply()
}

val matchList = mutableStateListOf<Match>()

fun startOfDay(ms: Long): Long {
    val c = java.util.Calendar.getInstance()
    c.timeInMillis = ms
    c.set(java.util.Calendar.HOUR_OF_DAY, 0); c.set(java.util.Calendar.MINUTE, 0)
    c.set(java.util.Calendar.SECOND, 0); c.set(java.util.Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

fun dayLabel(ts: Long): String {
    val diff = Math.round((startOfDay(ts) - startOfDay(System.currentTimeMillis())) / 86400000.0).toInt()
    return when (diff) {
        0 -> "اليوم"; 1 -> "غداً"; -1 -> "أمس"
        else -> java.text.SimpleDateFormat("EEEE d/M", java.util.Locale("ar")).format(java.util.Date(ts))
    }
}

fun applyMatches(txt: String) {
    val arr = JSONObject(txt).optJSONArray("matches") ?: return
    val list = ArrayList<Match>()
    for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        val ts = o.getLong("ts")
        val day = dayLabel(ts)
        if (day != "اليوم") continue
        val st = o.optString("status")
        val hs = if (o.isNull("hs")) null else o.getInt("hs")
        val aw = if (o.isNull("as")) null else o.getInt("as")
        val live = st == "LIVE"
        val fin = st == "FINISHED"
        val lg = o.optString("league")
        list.add(Match(lg, o.getString("home"), o.getString("away"), day,
            java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date(ts)), live, leagueChannels[lg],
            if (hs != null && aw != null && (live || fin)) "$hs - $aw" else null, fin,
            if (o.isNull("hc")) null else o.getString("hc"), if (o.isNull("ac")) null else o.getString("ac")))
    }
    matchList.clear()
    matchList.addAll(list.sortedBy { if (it.live) 0 else if (it.finished) 2 else 1 })
}

fun loadMatchesCache(ctx: Context) {
    try { applyMatches(prefs(ctx).getString("matches", "{}") ?: "{}") } catch (_: Exception) {}
}

fun syncMatches(ctx: Context) {
    Thread {
        try {
            val c = URL("$RAW_BASE/matches.json?t=${System.currentTimeMillis()}").openConnection() as HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 8000
            if (c.responseCode == 200) {
                val txt = c.inputStream.bufferedReader().readText()
                ui { try { applyMatches(txt); prefs(ctx).edit().putString("matches", txt).apply() } catch (_: Exception) {} }
            }
        } catch (_: Exception) {}
    }.start()
}

class Favs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("ohtman", 0)
    val ids = mutableStateListOf<String>().apply { addAll(sp.getStringSet("f", emptySet()) ?: emptySet()) }
    fun toggle(id: String) {
        if (id in ids) ids.remove(id) else ids.add(id)
        sp.edit().putStringSet("f", ids.toSet()).apply()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun Splash() {
    val a = remember { Animatable(0f) }
    val sc = remember { Animatable(.75f) }
    val b = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { sc.animateTo(1f, tween(1100, easing = FastOutSlowInEasing)) }
        a.animateTo(1f, tween(1000))
        b.animateTo(1f, tween(900))
    }
    Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF2B2108), Bg), radius = 1100f)), contentAlignment = Alignment.Center) {
        Box(Modifier.size(340.dp).graphicsLayer { alpha = a.value }
            .background(Brush.radialGradient(listOf(Gold.copy(alpha = .20f), Color.Transparent)), CircleShape))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(Modifier.graphicsLayer { alpha = a.value; scaleX = sc.value; scaleY = sc.value }, verticalAlignment = Alignment.CenterVertically) {
                Text("ohtman", color = Color.White, fontSize = 46.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.width(8.dp))
                Text("TV", color = Bg, fontSize = 32.sp, fontWeight = FontWeight.Black,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFFFFE08A), Gold, Color(0xFFB8860B)))).padding(14.dp, 2.dp))
            }
            }
            Spacer(Modifier.height(18.dp))
            Box(Modifier.graphicsLayer { alpha = b.value }.width(90.dp).height(3.dp).clip(CircleShape)
                .background(Brush.horizontalGradient(listOf(Color.Transparent, Gold, Color.Transparent))))
            Spacer(Modifier.height(18.dp))
            Text("مرحباً بك في عالم الفرجة", modifier = Modifier.graphicsLayer { alpha = b.value },
                style = TextStyle(brush = Brush.linearGradient(listOf(Color(0xFFFFE08A), Gold, Color(0xFFD4A017))),
                    fontSize = 24.sp, fontWeight = FontWeight.Bold))
            Spacer(Modifier.height(8.dp))
            Text("قنوات • مباريات • أفلام • بث مباشر", color = Muted, fontSize = 13.sp, modifier = Modifier.graphicsLayer { alpha = b.value })
        }
        CircularProgressIndicator(Modifier.align(Alignment.BottomCenter).padding(bottom = 56.dp).size(26.dp).graphicsLayer { alpha = b.value },
            color = Gold, strokeWidth = 2.dp)
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val favs = remember { Favs(ctx) }
    remember { ImageLoader.Builder(ctx).components { add(SvgDecoder.Factory()) }.crossfade(true).build().also { imgLoader = it } }
    LaunchedEffect(Unit) { loadLogos(ctx); loadCustom(ctx); adminState.value = ctx.getSharedPreferences("ohtman", 0).getBoolean("admin", false); bufProfile.value = prefs(ctx).getInt("buf", 2); qNames.value = prefs(ctx).getBoolean("qnames", true); loadMatchesCache(ctx); syncCatalog(ctx); syncMatches(ctx) }
    LaunchedEffect(Unit) { while (true) { delay(180000); syncMatches(ctx) } }
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { delay(3600); splash = false }
    var tab by remember { mutableStateOf(0) }
    var current by remember { mutableStateOf<Channel?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var showAdmin by remember { mutableStateOf(false) }
    var showM3u by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var tgPrompt by remember { mutableStateOf(true) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Bg, surface = Surf)) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Crossfade(targetState = splash, animationSpec = tween(700), label = "splash") { showSplash ->
                if (showSplash) Splash() else Box(Modifier.fillMaxSize().background(Bg)) {
                    val c = current
                    if (showEditor) ChannelEditor(null) { showEditor = false }
                    if (showAdmin) AdminDialog { showAdmin = false }
                    if (showM3u) M3uImporter { showM3u = false }
                    if (tgPrompt) TelegramPrompt { tgPrompt = false }
                    SideMenu(menuOpen) { menuOpen = false }
                    if (c != null) {
                        key(bufProfile.value) { PlayerScreen(c, favs, onBack = { current = null }, onPick = { current = it }) }
                    } else {
                        val play: (Channel) -> Unit = { current = it }
                        Scaffold(containerColor = Bg, topBar = { TopNav(tab, { showEditor = true }, { showM3u = true }, { showAdmin = true }, { menuOpen = true }) { tab = it } }) { pad ->
                            when {
                                tab == 0 -> Home(pad, play)
                                tab == 1 -> Matches(pad) { id -> allChannels().firstOrNull { it.id == id }?.let(play) }
                                tab >= 2 -> allSections().getOrNull(tab - 2)?.let { CategoryScreen(pad, it, play) } ?: Home(pad, play)
                                tab == -1 -> Favorites(pad, favs, play)
                                else -> SearchScreen(pad, play)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Logo(onLong: () -> Unit = {}) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(Modifier.combinedClickable(onClick = {}, onLongClick = onLong).padding(20.dp, 8.dp, 20.dp, 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("ohtman", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.width(4.dp))
            Text("TV", color = Bg, fontSize = 17.sp, fontWeight = FontWeight.Black,
                modifier = Modifier.clip(RoundedCornerShape(7.dp)).background(Gold).padding(7.dp, 1.dp))
        }
    }
}

@Composable
fun LiveBadge() {
    Row(Modifier.clip(RoundedCornerShape(6.dp)).background(Live).padding(7.dp, 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(6.dp).clip(CircleShape).background(Color.White))
        Spacer(Modifier.width(4.dp))
        Text("مباشر", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SectionTitle(t: String) {
    Row(Modifier.padding(20.dp, 22.dp, 20.dp, 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(4.dp, 18.dp).clip(CircleShape).background(Gold))
        Spacer(Modifier.width(8.dp))
        Text(t, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Chip(label: String, sel: Boolean, onClick: () -> Unit) {
    Text(label, color = if (sel) Bg else Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (sel) Gold else Surf).clickable(onClick = onClick).padding(18.dp, 9.dp))
}

@Composable
fun ChannelCard(ch: Channel, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.aspectRatio(16 / 10f).clip(RoundedCornerShape(16.dp)).background(grad(ch.color)).clickable(onClick = onClick)) {
        Text(ch.name.first().toString(), color = Color.White.copy(.1f), fontSize = 100.sp, fontWeight = FontWeight.Black,
            modifier = Modifier.align(Alignment.CenterStart).padding(start = 10.dp))
        logoMap[ch.id]?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        Box(Modifier.fillMaxWidth().align(Alignment.BottomCenter)
            .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.75f)))).padding(10.dp, 18.dp, 10.dp, 10.dp)) {
            Text(ch.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
        }
    }
}

fun LazyListScope.channelGrid(list: List<Channel>, onPlay: (Channel) -> Unit) {
    items(list.chunked(2)) { row ->
        Row(Modifier.padding(16.dp, 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            row.forEach { ch -> ChannelCard(ch, Modifier.weight(1f)) { onPlay(ch) } }
            if (row.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
fun Hero(list: List<Channel>, onPlay: (Channel) -> Unit) {
    val st = rememberPagerState { list.size }
    LaunchedEffect(Unit) { while (true) { delay(4500); st.animateScrollToPage((st.currentPage + 1) % list.size) } }
    Column {
        HorizontalPager(st, contentPadding = PaddingValues(horizontal = 16.dp), pageSpacing = 12.dp) { i ->
            val ch = list[i]
            Box(Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(24.dp)).background(grad(ch.color)).clickable { onPlay(ch) }) {
                Text(ch.name.first().toString(), color = Color.White.copy(.1f), fontSize = 190.sp, fontWeight = FontWeight.Black,
                    modifier = Modifier.align(Alignment.CenterEnd).padding(end = 16.dp))
                logoMap[ch.id]?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.8f)))))
                Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
                    LiveBadge()
                    Spacer(Modifier.height(8.dp))
                    Text(ch.name, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    Text(ch.desc, color = Color.White.copy(.7f), fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.clip(RoundedCornerShape(50)).background(Gold).padding(16.dp, 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.PlayArrow, null, tint = Bg, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("مشاهدة الآن", color = Bg, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.Center) {
            repeat(list.size) { i ->
                Box(Modifier.padding(3.dp).height(6.dp).width(if (i == st.currentPage) 18.dp else 6.dp).clip(CircleShape)
                    .background(if (i == st.currentPage) Gold else Color.White.copy(.25f)))
            }
        }
    }
}

@Composable
fun TopNav(tab: Int, onAdd: () -> Unit, onM3u: () -> Unit, onSecret: () -> Unit, onMenu: () -> Unit, onTab: (Int) -> Unit) {
    val labels = listOf("الرئيسية", "المباريات") + allSections().map { it.title }
    val ctx = LocalContext.current
    var delTitle by remember { mutableStateOf<String?>(null) }
    delTitle?.let { t ->
        AlertDialog(onDismissRequest = { delTitle = null }, containerColor = Surf,
            title = { Text("حذف القسم؟", color = Color.White, fontWeight = FontWeight.Bold) },
            text = { Text("سيُحذف القسم «$t» مع كل قنواته، ويختفي عند كل المستخدمين.", color = Muted) },
            confirmButton = { TextButton(onClick = { deleteSection(ctx, t); delTitle = null; onTab(0) }) { Text("حذف", color = Live, fontWeight = FontWeight.Bold) } },
            dismissButton = { TextButton(onClick = { delTitle = null }) { Text("إلغاء", color = Muted) } })
    }
    Column(Modifier.fillMaxWidth().background(Bg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Logo(onSecret)
                if (adminState.value) Text("ADMIN", color = Bg, fontSize = 9.sp, fontWeight = FontWeight.Black,
                    modifier = Modifier.clip(RoundedCornerShape(5.dp)).background(Gold).padding(5.dp, 1.dp))
            }
            IconButton(onClick = { onTab(-2) }) { Icon(Icons.Filled.Search, null, tint = if (tab == -2) Gold else Color.White) }
            IconButton(onClick = { onTab(-1) }) { Icon(Icons.Filled.Favorite, null, tint = if (tab == -1) Gold else Color.White) }
            IconButton(onClick = onMenu) { Icon(Icons.Filled.Menu, null, tint = Color.White) }
            Spacer(Modifier.width(4.dp))
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp)) {
            labels.forEachIndexed { i, l ->
                Column(Modifier.combinedClickable(onClick = { onTab(i) }, onLongClick = { if (adminState.value && i >= 2) delTitle = l }).padding(14.dp, 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(l, color = if (tab == i) Gold else Muted, fontSize = 15.sp, fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Medium)
                    Spacer(Modifier.height(6.dp))
                    Box(Modifier.height(3.dp).width(24.dp).clip(CircleShape).background(if (tab == i) Gold else Color.Transparent))
                }
            }
        }
        if (adminState.value) Row(Modifier.padding(16.dp, 4.dp, 16.dp, 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill(Icons.Filled.Add, "إضافة قناة", onAdd)
            Pill(Icons.Filled.Menu, "استيراد M3U", onM3u)
        }
        if (adminState.value) Text("اضغط مطولاً على اسم أي قسم لحذفه", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(20.dp, 0.dp, 20.dp, 6.dp))
        Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(.07f)))
    }
}

@Composable
fun CategoryScreen(pad: PaddingValues, s: Section, onPlay: (Channel) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad) {
        item { SectionTitle(s.title) }
        if (s.channels.isEmpty()) item {
            Text("لا توجد قنوات في هذا القسم بعد", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(24.dp))
        }
        channelGrid(s.channels, onPlay)
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun Home(pad: PaddingValues, onPlay: (Channel) -> Unit) {
    val secs = allSections()
    val todayMatches = matchList.filter { it.day == "اليوم" }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad) {
        item { Spacer(Modifier.height(12.dp)); Banners() }
        if (todayMatches.isNotEmpty()) item {
            SectionTitle("مباريات اليوم")
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(todayMatches) { m ->
                    MatchCard(m, Modifier.width(300.dp)) { id -> allChannels().firstOrNull { it.id == id }?.let(onPlay) }
                }
            }
        }
        secs.filter { it.channels.isNotEmpty() }.forEach { sec ->
            item {
                SectionTitle(sec.title)
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(sec.channels) { ch -> ChannelCard(ch, Modifier.width(180.dp)) { onPlay(ch) } }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun Team(name: String, crest: String?, modifier: Modifier) {
    val ctx = LocalContext.current
    val tid = "t_" + Integer.toHexString(name.lowercase().hashCode())
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) { saveLogo(ctx, tid, uri); dirtyLogos.add(tid); publish(ctx) }
    }
    val custom = logoMap[tid]
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        val letter: @Composable () -> Unit = { Text(name.first().toString(), color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        Box(Modifier.size(56.dp).clip(CircleShape)
            .background(if (custom != null || crest != null) Color(0xFFF2F2F5) else Color(0xFF23232F))
            .then(if (adminState.value) Modifier.combinedClickable(onClick = { picker.launch("image/*") }, onLongClick = { adminRemoveLogo(ctx, tid) }) else Modifier),
            contentAlignment = Alignment.Center) {
            if (custom != null) Image(custom, null, Modifier.fillMaxSize().padding(8.dp), contentScale = ContentScale.Fit)
            else if (crest != null) SubcomposeAsyncImage(model = crest, imageLoader = imgLoader, contentDescription = null,
                modifier = Modifier.fillMaxSize().padding(9.dp), loading = { letter() }, error = { letter() })
            else letter()
        }
        Spacer(Modifier.height(6.dp))
        Text(name, color = Color.White, fontSize = 13.sp, textAlign = TextAlign.Center, maxLines = 1)
        if (adminState.value) Text("اضغط للشعار • مطولاً للحذف", color = Muted, fontSize = 9.sp, textAlign = TextAlign.Center, maxLines = 1)
    }
}

@Composable
fun ChannelPicker(league: String, onDone: () -> Unit) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    val list = allChannels().filter { q.isBlank() || it.name.contains(q.trim(), true) }
    AlertDialog(onDismissRequest = onDone, containerColor = Surf,
        title = { Text("القناة الناقلة لـ $league", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column {
                Field(q, { q = it }, "ابحث عن قناة")
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(list) { ch ->
                        Text(ch.name, color = Color.White, modifier = Modifier.fillMaxWidth().clickable {
                            leagueMap[league] = ch.id; publish(ctx); onDone()
                        }.padding(12.dp))
                    }
                }
            }
        },
        confirmButton = {
            if (leagueMap[league] != null) TextButton(onClick = { leagueMap.remove(league); publish(ctx); onDone() }) { Text("إزالة الربط", color = Live) }
        },
        dismissButton = { TextButton(onClick = onDone) { Text("إلغاء", color = Muted) } })
}

@Composable
fun MatchCard(m: Match, modifier: Modifier = Modifier, onWatch: (String) -> Unit) {
    var pick by remember { mutableStateOf(false) }
    val chId = leagueMap[m.league] ?: m.channelId
    val chName = chId?.let { id -> allChannels().firstOrNull { it.id == id }?.name }
    if (pick) ChannelPicker(m.league) { pick = false }
    Column(modifier.clip(RoundedCornerShape(20.dp)).background(Surf).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(m.league, color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f), maxLines = 1)
            if (m.live) LiveBadge()
        }
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Team(m.home, m.homeCrest, Modifier.weight(1f))
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(64.dp)) {
                Text(m.score ?: if (m.live) "VS" else m.time, color = if (m.live) Live else Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                Text(if (m.finished) "انتهت" else m.day, color = Muted, fontSize = 11.sp)
            }
            Team(m.away, m.awayCrest, Modifier.weight(1f))
        }
        if (chName != null) {
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("📺 القناة الناقلة: $chName", color = Gold, fontSize = 12.sp, modifier = Modifier.weight(1f), maxLines = 1)
                if (adminState.value) Text("تغيير", color = Muted, fontSize = 12.sp, modifier = Modifier.clickable { pick = true }.padding(4.dp))
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (m.live) Gold else Color(0xFF23232F))
                .clickable { onWatch(chId ?: "") }.padding(10.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.PlayArrow, null, tint = if (m.live) Bg else Gold, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(4.dp))
                Text("مشاهدة البث", color = if (m.live) Bg else Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        } else if (adminState.value) {
            Spacer(Modifier.height(12.dp))
            Text("＋ ربط قناة ناقلة لهذا الدوري", color = Gold, fontSize = 12.sp,
                modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xFF23232F)).clickable { pick = true }.padding(12.dp, 8.dp))
        }
    }
}

@Composable
fun Matches(pad: PaddingValues, onWatch: (String) -> Unit) {
    val grouped = matchList.groupBy { it.day }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad) {
        if (grouped.isEmpty()) item {
            Text("لا توجد مباريات حالياً… يتم التحديث تلقائياً", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(24.dp))
        }
        grouped.forEach { (day, list) ->
            item { SectionTitle("مباريات $day") }
            items(list) { m -> MatchCard(m, Modifier.padding(16.dp, 6.dp).fillMaxWidth(), onWatch) }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun Favorites(pad: PaddingValues, favs: Favs, onPlay: (Channel) -> Unit) {
    val list = allChannels().filter { it.id in favs.ids }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad) {
        item { SectionTitle("المفضلة") }
        if (list.isEmpty()) item {
            Column(Modifier.fillMaxWidth().padding(40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.FavoriteBorder, null, tint = Muted, modifier = Modifier.size(56.dp))
                Spacer(Modifier.height(12.dp))
                Text("لا توجد قنوات مفضلة بعد", color = Color.White, fontWeight = FontWeight.Bold)
                Text("اضغط على القلب داخل أي قناة لإضافتها", color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
            }
        } else channelGrid(list, onPlay)
    }
}

@Composable
fun SearchScreen(pad: PaddingValues, onPlay: (Channel) -> Unit) {
    var q by remember { mutableStateOf("") }
    val res = if (q.isBlank()) allChannels() else allChannels().filter { it.name.contains(q.trim(), true) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad) {
        item {
            TextField(value = q, onValueChange = { q = it }, singleLine = true, shape = RoundedCornerShape(16.dp),
                placeholder = { Text("ابحث عن قناة...") }, leadingIcon = { Icon(Icons.Filled.Search, null) },
                colors = TextFieldDefaults.colors(focusedContainerColor = Surf, unfocusedContainerColor = Surf,
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, cursorColor = Gold),
                modifier = Modifier.fillMaxWidth().padding(16.dp, 4.dp, 16.dp, 12.dp))
        }
        channelGrid(res, onPlay)
    }
}

@Composable
fun RoundBtn(modifier: Modifier, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(modifier.padding(12.dp).size(40.dp).clip(CircleShape).background(Color.Black.copy(.55f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center) { content() }
}

@Composable
fun Pill(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(50)).background(Surf).clickable(onClick = onClick).padding(14.dp, 9.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Gold, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun PlayerScreen(ch: Channel, favs: Favs, onBack: () -> Unit, onPick: (Channel) -> Unit) {
    val ctx = LocalContext.current
    val act = ctx as Activity
    var full by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf(false) }
    var buffering by remember { mutableStateOf(true) }
    var mode by remember { mutableStateOf(0) }
    var showCtl by remember { mutableStateOf(true) }
    var wantPlay by remember { mutableStateOf(true) }
    var pos by remember { mutableStateOf(0L) }
    var dur by remember { mutableStateOf(0L) }
    var live by remember { mutableStateOf(true) }
    var vol by remember { mutableStateOf(1f) }
    var lastVol by remember { mutableStateOf(1f) }
    var tick by remember { mutableStateOf(0) }
    var inPip by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var maxH by remember { mutableStateOf(0) }
    var speed by remember { mutableStateOf(1f) }
    var modeMsg by remember { mutableStateOf("") }
    var modeTick by remember { mutableStateOf(0) }
    var editing by remember { mutableStateOf(false) }
    var confirmDel by remember { mutableStateOf(false) }
    val modes = remember {
        listOf("ملاءمة" to AspectRatioFrameLayout.RESIZE_MODE_FIT, "تكبير" to AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
            "تمديد" to AspectRatioFrameLayout.RESIZE_MODE_FILL, "عرض" to AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH,
            "طول" to AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT)
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) { saveLogo(ctx, ch.id, uri); dirtyLogos.add(ch.id); publish(ctx) } }
    val prof = remember { bufProfile.value }
    val player = remember { buildPlayer(ctx, prof) }
    var srcIdx by remember { mutableStateOf(0) }
    val retries = remember { intArrayOf(0) }
    val urlsNow = rememberUpdatedState(ch.sources())
    val capH = remember { intArrayOf(0) }
    val stallAt = remember { longArrayOf(0L) }
    val stallN = remember { intArrayOf(0) }
    var reconnecting by remember { mutableStateOf(false) }
    val applyCap: (Int) -> Unit = { h ->
        capH[0] = h
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setMaxVideoSize(Int.MAX_VALUE, if (h == 0) Int.MAX_VALUE else h).build()
    }
    // ضعف الشبكة: انزل بالجودة (مصدر أقل، أو سقف دقة للبث التكيّفي)
    val stepDown: () -> Unit = {
        val list = urlsNow.value
        if (srcIdx < list.size - 1) {
            srcIdx++
            toast(ctx, "ضعف الشبكة… التحويل إلى ${list[srcIdx].label}")
        } else {
            val next = when { capH[0] == 0 -> 720; capH[0] > 480 -> 480; capH[0] > 360 -> 360; else -> 240 }
            if (next != capH[0]) applyCap(next)
        }
    }
    // استقرار الشبكة: ارفع الجودة تدريجياً
    val stepUp: () -> Unit = {
        if (capH[0] != 0) {
            applyCap(when { capH[0] <= 240 -> 360; capH[0] <= 360 -> 480; capH[0] <= 480 -> 720; else -> 0 })
        } else if (srcIdx > 0) {
            srcIdx--
            toast(ctx, "الشبكة مستقرة… العودة إلى ${urlsNow.value[srcIdx].label}")
        }
    }
    // إعادة تشغيل تلقائية دون ضغط أي زر
    val recover: () -> Unit = {
        retries[0]++
        val n = retries[0]
        reconnecting = true
        if (n >= 10) err = true
        if (n % 3 == 0) {
            val list = urlsNow.value
            if (list.size > 1) {
                srcIdx = (srcIdx + 1) % list.size
                toast(ctx, "إعادة الاتصال عبر ${list[srcIdx].label}")
            } else stepDown()
        }
        Handler(Looper.getMainLooper()).postDelayed({ try { player.seekToDefaultPosition(); player.prepare() } catch (_: Exception) {} }, minOf(1500L * n, 8000L))
    }

    LaunchedEffect(ch.id) { srcIdx = 0; retries[0] = 0 }
    LaunchedEffect(ch.id, ch.url, srcIdx) {
        val list = urlsNow.value
        val b = MediaItem.Builder().setUri(list[srcIdx.coerceIn(0, list.size - 1)].url)
        if (prof >= 2) b.setLiveConfiguration(MediaItem.LiveConfiguration.Builder()
            .setTargetOffsetMs(if (prof == 2) 10000L else 18000L).setMinPlaybackSpeed(1f).setMaxPlaybackSpeed(1f).build())
        err = false; player.setMediaItem(b.build()); player.prepare()
    }
    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            var last = Player.STATE_IDLE
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_BUFFERING && last == Player.STATE_READY) {
                    val now = System.currentTimeMillis()
                    stallN[0] = if (now - stallAt[0] < 40000) stallN[0] + 1 else 1
                    stallAt[0] = now
                    if (stallN[0] >= 2) { stallN[0] = 0; stepDown() }
                }
                if (state == Player.STATE_READY) { err = false; reconnecting = false }
                if (state == Player.STATE_ENDED && live) recover()
                last = state
            }
            override fun onPlayerError(error: PlaybackException) { recover() }
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) { wantPlay = playWhenReady }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }
    DisposableEffect(full) {
        val ctl = WindowCompat.getInsetsController(act.window, act.window.decorView)
        if (full) {
            act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            ctl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            ctl.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            ctl.show(WindowInsetsCompat.Type.systemBars())
        }
        onDispose { act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED; ctl.show(WindowInsetsCompat.Type.systemBars()) }
    }
    BackHandler { if (full) full = false else onBack() }
    LaunchedEffect(Unit) { while (true) { pos = player.currentPosition; dur = player.duration; live = player.isCurrentMediaItemLive || dur <= 0; delay(500) } }
    LaunchedEffect(showCtl, tick, wantPlay) { if (showCtl && wantPlay) { delay(4000); showCtl = false } }
    LaunchedEffect(buffering) {
        if (buffering) {
            while (player.playbackState == Player.STATE_BUFFERING) {
                delay(8000)
                if (player.playbackState == Player.STATE_BUFFERING) recover()
            }
        }
    }
    LaunchedEffect(Unit) {
        var ok = 0
        while (true) {
            delay(1000)
            if (player.isPlaying) {
                ok++
                if (ok == 10) { retries[0] = 0; reconnecting = false; err = false }
                if (ok >= 180) { stepUp(); ok = 0 }
            } else ok = 0
        }
    }
    DisposableEffect(Unit) {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var first = true
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                if (first) { first = false; return }
                ui { if (!player.isPlaying) { retries[0] = 0; try { player.seekToDefaultPosition(); player.prepare() } catch (_: Exception) {} } }
            }
        }
        try { cm.registerDefaultNetworkCallback(cb) } catch (_: Exception) {}
        onDispose { try { cm.unregisterNetworkCallback(cb) } catch (_: Exception) {} }
    }
    LaunchedEffect(modeTick) { if (modeMsg.isNotEmpty()) { delay(1200); modeMsg = "" } }
    DisposableEffect(Unit) {
        val l = Consumer<PictureInPictureModeChangedInfo> { info -> inPip = info.isInPictureInPictureMode }
        (ctx as ComponentActivity).addOnPictureInPictureModeChangedListener(l)
        onDispose { (ctx as ComponentActivity).removeOnPictureInPictureModeChangedListener(l) }
    }
    if (settings) {
        val hs = player.currentTracks.groups.filter { g -> g.type == C.TRACK_TYPE_VIDEO }
            .flatMap { g -> (0 until g.length).map { i -> g.getTrackFormat(i).height } }.filter { h -> h > 0 }.distinct().sortedDescending()
        SettingsDialog(hs, maxH, { h ->
            maxH = h
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setMaxVideoSize(Int.MAX_VALUE, if (h == 0) Int.MAX_VALUE else h).build()
        }, modes.map { it.first }, mode, { mode = it }, speed, { sp -> speed = sp; player.setPlaybackSpeed(sp) },
            prof, { b -> prefs(ctx).edit().putInt("buf", b).apply(); bufProfile.value = b; toast(ctx, "تم تطبيق ثبات البث") },
            urlsNow.value.map { it.label }, srcIdx, { i -> srcIdx = i; retries[0] = 0 },
            qNames.value, { v -> qNames.value = v; prefs(ctx).edit().putBoolean("qnames", v).apply() }) { settings = false }
    }
    if (editing) ChannelEditor(allChannels().firstOrNull { it.id == ch.id }) { c -> editing = false; if (c != null) onPick(c) }
    if (confirmDel) AlertDialog(onDismissRequest = { confirmDel = false }, containerColor = Surf,
        title = { Text("حذف القناة؟", color = Color.White, fontWeight = FontWeight.Bold) },
        text = { Text("سيتم حذف ${ch.name} نهائياً", color = Muted) },
        confirmButton = { TextButton(onClick = { deleteCustom(ctx, ch.id); onBack() }) { Text("حذف", color = Live) } },
        dismissButton = { TextButton(onClick = { confirmDel = false }) { Text("إلغاء", color = Muted) } })

    Column(Modifier.fillMaxSize().background(Bg)) {
        Box(if (full || inPip) Modifier.fillMaxSize().background(Color.Black) else Modifier.fillMaxWidth().aspectRatio(16 / 9f).background(Color.Black)) {
            AndroidView(modifier = Modifier.fillMaxSize(), factory = { c ->
                PlayerView(c).apply { this.player = player; keepScreenOn = true; useController = false }
            }, update = { it.resizeMode = modes[mode].second })
            if (!inPip) {
                Box(Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { showCtl = !showCtl; tick++ })
                val wmBottom by animateDpAsState(if (showCtl) 108.dp else 14.dp, label = "wm")
                Text(buildAnnotatedString {
                    withStyle(SpanStyle(color = Color.White.copy(alpha = .45f))) { append("Ohtman") }
                    withStyle(SpanStyle(color = Gold.copy(alpha = .65f))) { append("TV") }
                }, style = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, shadow = Shadow(Color.Black.copy(alpha = .5f), Offset(1.5f, 1.5f), 4f)),
                    modifier = Modifier.align(Alignment.BottomStart).padding(start = 14.dp, bottom = wmBottom))
                if (modeMsg.isNotEmpty()) Text(modeMsg, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 16.dp).clip(RoundedCornerShape(50))
                        .background(Color.Black.copy(alpha = .6f)).padding(14.dp, 6.dp))
                if (showCtl) {
                    RoundBtn(Modifier.align(Alignment.TopStart), { if (full) full = false else onBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
                    }
                    if (urlsNow.value.size > 1) CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Row(Modifier.align(Alignment.TopEnd).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            urlsNow.value.forEachIndexed { i, sc ->
                                Text(if (qNames.value) sc.label else "${i + 1}", color = Color.White, fontSize = 12.sp, fontWeight = if (srcIdx == i) FontWeight.Bold else FontWeight.Medium,
                                    modifier = Modifier.clip(CircleShape)
                                        .background(Color.White.copy(alpha = if (srcIdx == i) .38f else .18f))
                                        .border(2.dp, if (srcIdx == i) PlayerRed else Color.Transparent, CircleShape)
                                        .clickable { srcIdx = i; retries[0] = 0; tick++ }
                                        .then(if (qNames.value) Modifier.padding(11.dp, 7.dp) else Modifier.size(32.dp).wrapContentSize(Alignment.Center)))
                            }
                        }
                    }
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.75f))))
                            .padding(start = 12.dp, end = 12.dp, top = 28.dp, bottom = 6.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                                SkipBtn(false) { try { player.seekTo((player.currentPosition - 10000).coerceAtLeast(0)) } catch (_: Exception) {}; tick++ }
                                Box(Modifier.size(36.dp).clickable { player.playWhenReady = !player.playWhenReady; tick++ }, contentAlignment = Alignment.Center) {
                                    if (wantPlay) Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        repeat(2) { Box(Modifier.size(4.dp, 18.dp).clip(RoundedCornerShape(1.dp)).background(Color.White)) }
                                    } else Icon(Icons.Filled.PlayArrow, null, tint = Color.White, modifier = Modifier.size(28.dp))
                                }
                                SkipBtn(true) { try { player.seekTo(player.currentPosition + 10000) } catch (_: Exception) {}; tick++ }
                                Box(Modifier.size(34.dp).clickable {
                                    try { ctx.startActivity(Intent(Settings.ACTION_CAST_SETTINGS)) } catch (_: Exception) { toast(ctx, "الميزة غير متاحة على هذا الجهاز") }
                                }, contentAlignment = Alignment.Center) { CastIcon() }
                                Box(Modifier.size(34.dp).clickable {
                                    if (vol > 0f) { lastVol = vol; vol = 0f } else vol = if (lastVol > 0f) lastVol else 1f
                                    player.volume = vol; tick++
                                }, contentAlignment = Alignment.Center) { VolumeIcon(vol == 0f) }
                                Box(Modifier.size(34.dp).clickable {
                                    mode = (mode + 1) % modes.size
                                    modeMsg = "الحجم: " + modes[mode].first; modeTick++; tick++
                                }, contentAlignment = Alignment.Center) { ResizeIcon() }
                                Box(Modifier.size(34.dp).clickable {
                                    if (Build.VERSION.SDK_INT >= 26) {
                                        try { act.enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()) } catch (_: Exception) {}
                                    } else toast(ctx, "الميزة تتطلب أندرويد 8 فأعلى")
                                }, contentAlignment = Alignment.Center) { PipIcon() }
                                Box(Modifier.size(34.dp).clickable { settings = true; tick++ }, contentAlignment = Alignment.Center) {
                                    Icon(Icons.Filled.Settings, null, tint = Color.White, modifier = Modifier.size(22.dp))
                                }
                                Box(Modifier.size(34.dp).clickable { full = !full; tick++ }, contentAlignment = Alignment.Center) { FullscreenIcon(full) }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (!live) Text(fmtTime(pos), color = Color.White, fontSize = 10.sp)
                                ThinSlider(if (dur > 0 && !live) pos.toFloat() / dur else 1f, Modifier.weight(1f).padding(horizontal = 8.dp), PlayerRed, !live) { f ->
                                    player.seekTo((f * dur).toLong()); pos = (f * dur).toLong(); tick++
                                }
                                if (!live) Text(fmtTime(dur), color = Color.White, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
            if (buffering && !err) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Gold)
            if (reconnecting) Text("جارٍ إعادة الاتصال…", color = Color.White, fontSize = 13.sp, modifier = Modifier.align(Alignment.Center).padding(top = 64.dp))
            if (err) Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("تعذر تشغيل البث", color = Color.White)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { err = false; player.prepare() }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Bg)) { Text("إعادة المحاولة") }
            }
        }
        if (!full && !inPip) {
            val isFav = ch.id in favs.ids
            val others = allChannels().filter { it.id != ch.id }
            Column(Modifier.padding(20.dp)) {
                Text(ch.name, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                Text(ch.desc, color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                Pill(if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, if (isFav) "في المفضلة" else "أضف للمفضلة") { favs.toggle(ch.id) }
                if (adminState.value) {
                    Spacer(Modifier.height(14.dp))
                    Text("أدوات الأدمن", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill(Icons.Filled.Add, "رفع صورة للقناة") { picker.launch("image/*") }
                        if (logoMap[ch.id] != null) Pill(Icons.Filled.Delete, "حذف الصورة") { adminRemoveLogo(ctx, ch.id) }
                        if (ch.id in customSection) {
                            Pill(Icons.Filled.Create, "تعديل القناة") { editing = true }
                            Pill(Icons.Filled.Delete, "حذف القناة") { confirmDel = true }
                        }
                    }
                }
            }
            SectionTitle("قنوات أخرى")
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(others) { c -> ChannelCard(c, Modifier.width(170.dp)) { onPick(c) } }
            }
        }
    }
}

@Composable
fun SocialRow() {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxWidth().padding(20.dp, 28.dp, 20.dp, 32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("تابعنا على", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            socials.forEach { s ->
                Box(Modifier.size(42.dp).clip(CircleShape).background(Color(s.color)).clickable {
                    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(s.url))) } catch (_: Exception) {}
                }, contentAlignment = Alignment.Center) {
                    Text(s.glyph, color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("ohtmanTV © 2026", color = Muted.copy(.6f), fontSize = 11.sp)
    }
}

@Composable
fun Field(v: String, onChange: (String) -> Unit, label: String, uri: Boolean = false, pass: Boolean = false, secret: Boolean = false, multi: Boolean = false) {
    OutlinedTextField(value = v, onValueChange = onChange, label = { Text(label) }, singleLine = !multi, maxLines = if (multi) 6 else 1,
        keyboardOptions = KeyboardOptions(keyboardType = if (pass) KeyboardType.NumberPassword else if (secret) KeyboardType.Password else if (uri && !multi) KeyboardType.Uri else KeyboardType.Text),
        visualTransformation = if (pass || secret) PasswordVisualTransformation() else VisualTransformation.None,
        modifier = Modifier.fillMaxWidth().then(if (multi) Modifier.heightIn(min = 110.dp) else Modifier), shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Gold, unfocusedBorderColor = Color(0xFF3A3A48),
            focusedLabelColor = Gold, unfocusedLabelColor = Muted, cursorColor = Gold,
            focusedTextColor = Color.White, unfocusedTextColor = Color.White))
}

@Composable
fun ChannelEditor(existing: Channel?, onDone: (Channel?) -> Unit) {
    val ctx = LocalContext.current
    val id = remember { existing?.id ?: "c_${System.currentTimeMillis()}" }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    val q = remember { mutableStateMapOf<String, String>().apply { existing?.sources()?.forEach { put(it.label, it.url) } } }
    val url = encodeSources(q)
    val titles = allSections().map { it.title }
    var sec by remember { mutableStateOf(existing?.let { customSection[it.id] } ?: titles.firstOrNull() ?: "") }
    var newSec by remember { mutableStateOf("") }
    var isNew by remember { mutableStateOf(titles.isEmpty()) }
    var picked by remember { mutableStateOf<Uri?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { if (it != null) picked = it }
    val ok = name.isNotBlank() && url.isNotBlank() && (!isNew || newSec.isNotBlank())
    AlertDialog(onDismissRequest = { onDone(null) }, containerColor = Surf,
        title = { Text(if (existing == null) "إضافة قناة جديدة" else "تعديل القناة", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Field(name, { name = it }, "اسم القناة")
                qOrder.forEach { k ->
                    Field(q[k] ?: "", { v -> q[k] = v }, if (k == "Multi") "رابط Multi (الأساسي / تلقائي الجودة)" else "رابط $k (اختياري)", uri = true)
                }
                Text("يكفي رابط واحد. عند إضافة أكثر من رابط تظهر أزرار الجودة في المشغل.", color = Muted, fontSize = 11.sp)
                Text("القسم", color = Muted, fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    titles.forEach { t -> Chip(t, !isNew && sec == t) { isNew = false; sec = t } }
                    Chip("+ قسم جديد", isNew) { isNew = true }
                }
                if (isNew) Field(newSec, { newSec = it }, "اسم القسم الجديد")
                Pill(Icons.Filled.Add, if (picked != null || logoMap[id] != null) "تغيير الصورة ✓" else "اختيار صورة (اختياري)") { picker.launch("image/*") }
            }
        },
        confirmButton = {
            TextButton(enabled = ok, onClick = {
                val ch = addCustom(ctx, id, name.trim(), url.trim(), if (isNew) newSec.trim() else sec)
                picked?.let { saveLogo(ctx, id, it); dirtyLogos.add(id) }
                publish(ctx)
                onDone(ch)
            }) { Text("حفظ", color = if (ok) Gold else Muted, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = { onDone(null) }) { Text("إلغاء", color = Muted) } })
}

@Composable
fun AdminDialog(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    var token by remember { mutableStateOf(prefs(ctx).getString("gh_token", "") ?: "") }
    if (adminState.value) {
        AlertDialog(onDismissRequest = onDone, containerColor = Surf,
            title = { Text("وضع الأدمن مفعّل", color = Gold, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("أي تغيير تحفظه يُنشر تلقائياً لكل المستخدمين.", color = Muted, fontSize = 13.sp)
                    Field(token, { token = it }, "GitHub Token (للنشر)", secret = true)
                    Text(if (token.isBlank()) "⚠️ لم يُحفظ التوكن بعد" else "✓ التوكن محفوظ", color = if (token.isBlank()) Live else Gold, fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = { prefs(ctx).edit().putString("gh_token", token.trim()).apply(); syncCatalog(ctx); onDone() }) { Text("حفظ ومزامنة", color = Gold, fontWeight = FontWeight.Bold) } },
            dismissButton = {
                Row {
                    TextButton(onClick = { setAdmin(ctx, false); onDone() }) { Text("خروج", color = Live) }
                    TextButton(onClick = onDone) { Text("إغلاق", color = Muted) }
                }
            })
    } else {
        AlertDialog(onDismissRequest = onDone, containerColor = Surf,
            title = { Text("دخول الأدمن", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Field(pin, { pin = it; wrong = false }, "كلمة سر الأدمن", secret = true)
                    if (wrong) Text("الرمز غير صحيح", color = Live, fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = { if (sha256(pin.trim()) == ADMIN_HASH) { setAdmin(ctx, true); onDone() } else wrong = true }) { Text("دخول", color = Gold, fontWeight = FontWeight.Bold) } },
            dismissButton = { TextButton(onClick = onDone) { Text("إلغاء", color = Muted) } })
    }
}

fun sampled(bytes: ByteArray, max: Int = 480): Bitmap? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
    var sm = 1
    while (o.outWidth / sm > max) sm *= 2
    return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sm })
}

data class M3uItem(val name: String, val url: String, val group: String, val logo: String)

fun parseM3u(txt: String): List<M3uItem> {
    val out = ArrayList<M3uItem>()
    var name = ""; var group = ""; var logo = ""
    for (raw in txt.lines()) {
        val l = raw.trim()
        if (l.startsWith("#EXTINF")) {
            name = l.substringAfterLast(",", "").trim()
            group = Regex("group-title=\"([^\"]*)\"").find(l)?.groupValues?.get(1)?.trim() ?: ""
            logo = Regex("tvg-logo=\"([^\"]*)\"").find(l)?.groupValues?.get(1)?.trim() ?: ""
        } else if (l.isNotEmpty() && !l.startsWith("#")) {
            if (l.startsWith("http")) out.add(M3uItem(name.ifBlank { "قناة ${out.size + 1}" }, l, group, logo))
            name = ""; group = ""; logo = ""
        }
    }
    return out
}

fun importM3u(ctx: Context, items: List<M3uItem>, forced: String?) {
    items.forEach { m ->
        val id = "m_" + Integer.toHexString(m.url.hashCode())
        val ch = Channel(id, m.name, m.url, "⭐", "قناة مضافة", palette[Math.abs(id.hashCode()) % palette.size])
        val i = customList.indexOfFirst { it.id == id }
        if (i >= 0) customList[i] = ch else customList.add(ch)
        customSection[id] = forced ?: m.group.ifBlank { "مستوردة" }
        if (m.logo.startsWith("http")) logoUrls[id] = m.logo
    }
    publish(ctx)
    toast(ctx, "تم استيراد ${items.size} قناة")
}

@Composable
fun M3uImporter(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var link by remember { mutableStateOf("") }
    var pasted by remember { mutableStateOf("") }
    val titles = allSections().map { it.title }
    var forced by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = { if (!busy) onDone() }, containerColor = Surf,
        title = { Text("استيراد قائمة M3U", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Field(link, { link = it }, "رابط القائمة (http...)", uri = true)
                Field(pasted, { pasted = it }, "أو الصق محتوى القائمة هنا", multi = true)
                Text("القسم", color = Muted, fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("حسب القائمة", forced == null) { forced = null }
                    titles.forEach { t -> Chip(t, forced == t) { forced = t } }
                }
                Text("الحد الأقصى 500 قناة لكل استيراد", color = Muted, fontSize = 11.sp)
                if (msg.isNotEmpty()) Text(msg, color = Gold, fontSize = 12.sp)
            }
        },
        confirmButton = {
            TextButton(enabled = !busy && (link.isNotBlank() || pasted.isNotBlank()), onClick = {
                busy = true; msg = "جارٍ قراءة القائمة..."
                val l = link.trim(); val p = pasted; val f = forced
                Thread {
                    try {
                        val txt = if (l.isNotEmpty()) {
                            val c = URL(l).openConnection() as HttpURLConnection
                            c.connectTimeout = 15000; c.readTimeout = 30000
                            c.setRequestProperty("User-Agent", "Mozilla/5.0")
                            c.inputStream.bufferedReader().readText()
                        } else p
                        val items = parseM3u(txt).take(500)
                        ui {
                            if (items.isEmpty()) { msg = "لم أجد قنوات في هذه القائمة"; busy = false }
                            else { importM3u(ctx, items, f); busy = false; onDone() }
                        }
                    } catch (e: Exception) { ui { msg = "فشل: ${e.message}"; busy = false } }
                }.start()
            }) { Text(if (busy) "..." else "استيراد", color = Gold, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = { if (!busy) onDone() }) { Text("إلغاء", color = Muted) } })
}

@Composable
fun BoxScope.Promo() {
    Box(Modifier.size(230.dp).align(Alignment.CenterEnd).offset(x = 70.dp).background(Gold.copy(alpha = .10f), CircleShape))
    Box(Modifier.size(110.dp).align(Alignment.BottomEnd).offset(x = (-40).dp, y = 30.dp).background(Gold.copy(alpha = .08f), CircleShape))
    Column(Modifier.align(Alignment.CenterStart).padding(24.dp)) {
        Text("تابع دورياتك المفضلة", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text("ohtmanTV", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
        Text("عالم الفرجة بين يديك", color = Muted, fontSize = 13.sp)
    }
}

@Composable
fun Banners() {
    val ctx = LocalContext.current
    val ids = listOf("banner1", "banner2")
    var target by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && target.isNotEmpty()) { saveLogo(ctx, target, uri); dirtyLogos.add(target); publish(ctx) }
    }
    val admin = adminState.value
    val have = ids.filter { logoMap[it] != null }
    val pages = if (admin) ids else if (have.isEmpty()) listOf("default") else have
    val st = rememberPagerState { pages.size }
    LaunchedEffect(pages.size) { while (pages.size > 1) { delay(4500); st.animateScrollToPage((st.currentPage + 1) % pages.size) } }
    Column {
        HorizontalPager(st, contentPadding = PaddingValues(horizontal = 16.dp), pageSpacing = 12.dp) { i ->
            val id = pages[i]
            val bm = logoMap[id]
            Box(Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(24.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF3A2A06), Color(0xFF14110A))))
                .then(if (admin && bm == null) Modifier.clickable { target = id; picker.launch("image/*") } else Modifier)) {
                if (bm != null) Image(bm, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else if (id == "default") Promo()
                else Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.Add, null, tint = Gold, modifier = Modifier.size(36.dp))
                    Text("صورة الإشهار ${i + 1}", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("اضغط للرفع", color = Muted, fontSize = 12.sp)
                }
                if (admin && bm != null) Row(Modifier.align(Alignment.TopStart).padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(Icons.Filled.Add, "تغيير") { target = id; picker.launch("image/*") }
                    Pill(Icons.Filled.Delete, "حذف") { adminRemoveLogo(ctx, id) }
                }
            }
        }
        if (pages.size > 1) Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.Center) {
            repeat(pages.size) { i ->
                Box(Modifier.padding(3.dp).height(6.dp).width(if (i == st.currentPage) 18.dp else 6.dp).clip(CircleShape)
                    .background(if (i == st.currentPage) Gold else Color.White.copy(.25f)))
            }
        }
    }
}

val PlayerRed = Color(0xFFFF2D2D)

@Composable
fun ThinSlider(value: Float, modifier: Modifier = Modifier, color: Color = PlayerRed, enabled: Boolean = true, onChange: (Float) -> Unit) {
    var w by remember { mutableStateOf(1f) }
    val v = value.coerceIn(0f, 1f)
    Box(modifier.height(28.dp).onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f) }
        .pointerInput(enabled) { if (enabled) detectTapGestures { o -> onChange((o.x / w).coerceIn(0f, 1f)) } }
        .pointerInput(enabled) { if (enabled) detectHorizontalDragGestures { c, _ -> onChange((c.position.x / w).coerceIn(0f, 1f)) } }) {
        Box(Modifier.align(Alignment.CenterStart).fillMaxWidth().height(3.dp).background(Color.White.copy(alpha = .4f)))
        Box(Modifier.align(Alignment.CenterStart).fillMaxWidth(v).height(3.dp).background(color))
        Box(Modifier.align(Alignment.CenterStart).offset { IntOffset((v * w - 6.dp.toPx()).toInt(), 0) }.size(12.dp).background(color, CircleShape))
    }
}

@Composable
fun VolumeIcon(muted: Boolean) {
    Canvas(Modifier.size(22.dp)) {
        val w = size.width; val h = size.height
        val sp = Path().apply {
            moveTo(w * .08f, h * .38f); lineTo(w * .30f, h * .38f); lineTo(w * .52f, h * .18f)
            lineTo(w * .52f, h * .82f); lineTo(w * .30f, h * .62f); lineTo(w * .08f, h * .62f); close()
        }
        drawPath(sp, Color.White)
        val st = Stroke(2.dp.toPx(), cap = StrokeCap.Round)
        if (!muted) {
            drawArc(color = Color.White, startAngle = -50f, sweepAngle = 100f, useCenter = false, topLeft = Offset(w * .42f, h * .30f), size = Size(w * .26f, h * .40f), style = st)
            drawArc(color = Color.White, startAngle = -50f, sweepAngle = 100f, useCenter = false, topLeft = Offset(w * .42f, h * .14f), size = Size(w * .46f, h * .72f), style = st)
        } else {
            drawLine(Color.White, Offset(w * .66f, h * .36f), Offset(w * .94f, h * .64f), 2.dp.toPx(), StrokeCap.Round)
            drawLine(Color.White, Offset(w * .94f, h * .36f), Offset(w * .66f, h * .64f), 2.dp.toPx(), StrokeCap.Round)
        }
    }
}

@Composable
fun PipIcon() {
    Canvas(Modifier.size(22.dp)) {
        drawRoundRect(color = Color.White, topLeft = Offset(1.dp.toPx(), 4.dp.toPx()), size = Size(size.width - 2.dp.toPx(), size.height - 8.dp.toPx()),
            cornerRadius = CornerRadius(3.dp.toPx()), style = Stroke(2.dp.toPx()))
        drawRoundRect(color = Color.White, topLeft = Offset(size.width * .52f, size.height * .5f), size = Size(size.width * .36f, size.height * .26f),
            cornerRadius = CornerRadius(1.5.dp.toPx()))
    }
}

@Composable
fun FullscreenIcon(full: Boolean) {
    Canvas(Modifier.size(22.dp)) {
        val sw = 2.2.dp.toPx(); val w = size.width; val l = w * .3f
        fun br(x: Float, y: Float, dx: Float, dy: Float) {
            drawLine(Color.White, Offset(x, y), Offset(x + dx * l, y), sw, StrokeCap.Round)
            drawLine(Color.White, Offset(x, y), Offset(x, y + dy * l), sw, StrokeCap.Round)
        }
        if (!full) { br(2f, 2f, 1f, 1f); br(w - 2f, 2f, -1f, 1f); br(2f, w - 2f, 1f, -1f); br(w - 2f, w - 2f, -1f, -1f) }
        else { val a = w * .36f; val b = w * .64f; br(a, a, -1f, -1f); br(b, a, 1f, -1f); br(a, b, -1f, 1f); br(b, b, 1f, 1f) }
    }
}

@Composable
fun SettingsDialog(heights: List<Int>, maxH: Int, onQuality: (Int) -> Unit, labels: List<String>, mode: Int, onMode: (Int) -> Unit,
                   speed: Float, onSpeed: (Float) -> Unit, bufIdx: Int, onBuf: (Int) -> Unit,
                   srcLabels: List<String>, srcIdx: Int, onSrc: (Int) -> Unit, names: Boolean, onNames: (Boolean) -> Unit, onDone: () -> Unit) {
    AlertDialog(onDismissRequest = onDone, containerColor = Surf,
        title = { Text("إعدادات المشغل", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (heights.isNotEmpty()) {
                    Text("الجودة", color = Muted, fontSize = 12.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Chip("تلقائي", maxH == 0) { onQuality(0) }
                        heights.forEach { h -> Chip("${h}p", maxH == h) { onQuality(h) } }
                    }
                }
                if (srcLabels.size > 1) {
                    Text("الجودة / المصدر", color = Muted, fontSize = 12.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        srcLabels.forEachIndexed { i, l -> Chip(l, srcIdx == i) { onSrc(i) } }
                    }
                    Text("شكل أزرار المصدر في المشغل", color = Muted, fontSize = 11.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Chip("أرقام", !names) { onNames(false) }
                        Chip("أسماء", names) { onNames(true) }
                    }
                }
                Text("ثبات البث (يحلّ التقطيع)", color = Muted, fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("سريع", "متوازن", "ثابت", "أقصى").forEachIndexed { i, l -> Chip(l, bufIdx == i) { onBuf(i) } }
                }
                Text("«ثابت» و«أقصى» يحمّلان جزءاً أكبر قبل العرض فيقلّ التقطيع، وقد يتأخر بدء البث بضع ثوانٍ.", color = Muted, fontSize = 11.sp)
                Text("حجم الفيديو", color = Muted, fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    labels.forEachIndexed { i, l -> Chip(l, mode == i) { onMode(i) } }
                }
                Text("سرعة التشغيل", color = Muted, fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { sp -> Chip("${sp}x", speed == sp) { onSpeed(sp) } }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDone) { Text("تم", color = Gold, fontWeight = FontWeight.Bold) } })
}

@Composable
fun ResizeIcon() {
    Canvas(Modifier.size(22.dp)) {
        val w = size.width; val h = size.height
        drawRoundRect(color = Color.White, topLeft = Offset(1.dp.toPx(), 3.dp.toPx()), size = Size(w - 2.dp.toPx(), h - 6.dp.toPx()),
            cornerRadius = CornerRadius(3.dp.toPx()), style = Stroke(2.dp.toPx()))
        val t = 4.dp.toPx(); val sw = 2.dp.toPx()
        val ax = 5.dp.toPx(); val ay = 7.dp.toPx()
        drawLine(Color.White, Offset(ax, ay), Offset(ax + t, ay), sw, StrokeCap.Round)
        drawLine(Color.White, Offset(ax, ay), Offset(ax, ay + t), sw, StrokeCap.Round)
        val bx = w - 5.dp.toPx(); val by = h - 7.dp.toPx()
        drawLine(Color.White, Offset(bx, by), Offset(bx - t, by), sw, StrokeCap.Round)
        drawLine(Color.White, Offset(bx, by), Offset(bx, by - t), sw, StrokeCap.Round)
    }
}

val bufProfile = mutableStateOf(2)
val qNames = mutableStateOf(true)

data class Src(val label: String, val url: String)
private val qOrder = listOf("Multi", "HD", "720", "480", "SD", "Low")

fun Channel.sources(): List<Src> {
    val out = ArrayList<Src>()
    var extra = 1
    for (t in url.split(Regex("[\\s|]+")).map { it.trim() }.filter { it.isNotEmpty() }) {
        val m = Regex("^(multi|hd|sd|low|480|720|750)=(https?://\\S+)$", RegexOption.IGNORE_CASE).find(t)
        if (m != null) {
            val g = m.groupValues[1].let { x -> if (x == "750") "720" else x }
            val lb = qOrder.first { it.equals(g, true) }
            out.add(Src(lb, m.groupValues[2]))
        } else if (t.startsWith("http")) {
            out.add(Src(if (out.isEmpty()) "Multi" else "مصدر ${++extra}", t))
        }
    }
    if (out.isEmpty()) out.add(Src("Multi", url))
    return out.sortedBy { sc -> qOrder.indexOf(sc.label).let { i -> if (i < 0) 99 else i } }
}

fun encodeSources(m: Map<String, String>): String {
    val parts = qOrder.map { it to (m[it] ?: "").trim() }.filter { it.second.startsWith("http") }
    return when {
        parts.isEmpty() -> ""
        parts.size == 1 && parts[0].first == "Multi" -> parts[0].second
        else -> parts.joinToString("\n") { "${it.first}=${it.second}" }
    }
}

fun buildPlayer(ctx: Context, profile: Int): ExoPlayer {
    val (minB, maxB, playB, reB) = when (profile) {
        0 -> listOf(8000, 20000, 1500, 3000)
        1 -> listOf(15000, 40000, 2500, 5000)
        2 -> listOf(30000, 90000, 5000, 10000)
        else -> listOf(50000, 180000, 8000, 15000)
    }
    val lc = DefaultLoadControl.Builder().setBufferDurationsMs(minB, maxB, playB, reB).setPrioritizeTimeOverSizeThresholds(true).build()
    val http = DefaultHttpDataSource.Factory()
        .setUserAgent("Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36")
        .setConnectTimeoutMs(15000).setReadTimeoutMs(20000).setAllowCrossProtocolRedirects(true)
    val ext = DefaultExtractorsFactory().setTsExtractorFlags(
        DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS)
    val msf = DefaultMediaSourceFactory(DefaultDataSource.Factory(ctx, http), ext).setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(8))
    return ExoPlayer.Builder(ctx, DefaultRenderersFactory(ctx).setEnableDecoderFallback(true))
        .setLoadControl(lc).setMediaSourceFactory(msf).build().apply { playWhenReady = true }
}

fun fmtTime(ms: Long): String {
    val t = (ms / 1000).coerceAtLeast(0)
    val h = t / 3600; val m = (t % 3600) / 60; val sec = t % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

@Composable
fun SkipBtn(forward: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(36.dp).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(Icons.Filled.Refresh, null, tint = Color.White, modifier = Modifier.size(26.dp).graphicsLayer { scaleX = if (forward) 1f else -1f })
        Text("10", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun CastIcon() {
    Canvas(Modifier.size(22.dp)) {
        val w = size.width; val h = size.height
        val st = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        val box = Path().apply {
            moveTo(w * .42f, h * .80f); lineTo(w - 2.dp.toPx(), h * .80f); lineTo(w - 2.dp.toPx(), h * .20f)
            lineTo(2.dp.toPx(), h * .20f); lineTo(2.dp.toPx(), h * .38f)
        }
        drawPath(box, Color.White, style = st)
        val cx = 3.dp.toPx(); val cy = h * .82f
        drawCircle(Color.White, 1.6.dp.toPx(), Offset(cx, cy))
        for (r in listOf(6.dp.toPx(), 11.dp.toPx()))
            drawArc(color = Color.White, startAngle = 270f, sweepAngle = 90f, useCenter = false, topLeft = Offset(cx - r, cy - r), size = Size(2 * r, 2 * r), style = st)
    }
}

fun socialUrl(sc: Social) = socialUrls[sc.label] ?: sc.url

fun openUrl(ctx: Context, url: String) {
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {}
}

fun shareApp(ctx: Context) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, "حمّل تطبيق ohtmanTV — مرحباً بك في عالم الفرجة 📺\nhttps://github.com/$GH_REPO/releases/latest")
    }
    ctx.startActivity(Intent.createChooser(i, "مشاركة التطبيق"))
}

@Composable
fun SocialIcon(label: String, box: Dp = 40.dp) {
    Canvas(Modifier.size(box)) {
        val w = size.width; val h = size.height
        when (label) {
            "تيليجرام" -> {
                val blue = Color(0xFF27A7E7)
                drawCircle(color = blue)
                val p = Path().apply {
                    moveTo(w * .22f, h * .49f); lineTo(w * .79f, h * .27f); lineTo(w * .65f, h * .75f)
                    lineTo(w * .48f, h * .61f); lineTo(w * .38f, h * .72f); lineTo(w * .37f, h * .57f); close()
                }
                drawPath(p, Color.White)
                drawLine(blue, Offset(w * .38f, h * .58f), Offset(w * .66f, h * .38f), w * .025f, StrokeCap.Round)
            }
            "واتساب" -> {
                drawCircle(color = Color(0xFF25D366))
                val st = Stroke(w * .07f, cap = StrokeCap.Round)
                drawCircle(color = Color.White, radius = w * .26f, center = Offset(w * .5f, h * .48f), style = st)
                val tail = Path().apply { moveTo(w * .27f, h * .76f); lineTo(w * .31f, h * .58f); lineTo(w * .43f, h * .70f); close() }
                drawPath(tail, Color.White)
                drawLine(Color.White, Offset(w * .42f, h * .40f), Offset(w * .58f, h * .58f), w * .09f, StrokeCap.Round)
            }
            "فيسبوك" -> {
                drawCircle(color = Color(0xFF1877F2))
                val f = Path().apply {
                    moveTo(w * .55f, h * .84f); lineTo(w * .55f, h * .38f); quadraticBezierTo(w * .55f, h * .26f, w * .69f, h * .28f)
                    moveTo(w * .42f, h * .50f); lineTo(w * .68f, h * .50f)
                }
                drawPath(f, Color.White, style = Stroke(w * .09f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            "انستغرام" -> {
                val g = Brush.linearGradient(listOf(Color(0xFF7B2FF7), Color(0xFFE1306C), Color(0xFFFCAF45)), start = Offset(0f, h), end = Offset(w, 0f))
                drawRoundRect(brush = g, cornerRadius = CornerRadius(w * .28f))
                val st = Stroke(w * .065f, cap = StrokeCap.Round)
                drawRoundRect(color = Color.White, topLeft = Offset(w * .22f, h * .22f), size = Size(w * .56f, h * .56f), cornerRadius = CornerRadius(w * .16f), style = st)
                drawCircle(color = Color.White, radius = w * .13f, center = Offset(w * .5f, h * .5f), style = st)
                drawCircle(color = Color.White, radius = w * .035f, center = Offset(w * .67f, h * .33f))
            }
            "يوتيوب" -> {
                drawRoundRect(color = Color(0xFFFF0000), topLeft = Offset(0f, h * .2f), size = Size(w, h * .6f), cornerRadius = CornerRadius(w * .18f))
                val t = Path().apply { moveTo(w * .42f, h * .36f); lineTo(w * .42f, h * .64f); lineTo(w * .66f, h * .5f); close() }
                drawPath(t, Color.White)
            }
            "X" -> {
                drawCircle(color = Color.Black)
                drawCircle(color = Color.White.copy(alpha = .3f), radius = w * .49f, style = Stroke(w * .02f))
                drawLine(Color.White, Offset(w * .30f, h * .28f), Offset(w * .70f, h * .72f), w * .08f, StrokeCap.Round)
                drawLine(Color.White, Offset(w * .70f, h * .28f), Offset(w * .30f, h * .72f), w * .035f, StrokeCap.Round)
            }
            else -> drawCircle(color = Color(0xFF3A3A48))
        }
    }
}

@Composable
fun ShareIcon() {
    Canvas(Modifier.size(24.dp)) {
        val w = size.width; val h = size.height; val r = w * .12f; val sw = w * .07f
        val a = Offset(w * .78f, h * .2f); val b = Offset(w * .22f, h * .5f); val c = Offset(w * .78f, h * .8f)
        drawLine(Color.White, a, b, sw, StrokeCap.Round)
        drawLine(Color.White, b, c, sw, StrokeCap.Round)
        drawCircle(color = Color.White, radius = r, center = a)
        drawCircle(color = Color.White, radius = r, center = b)
        drawCircle(color = Color.White, radius = r, center = c)
    }
}

@Composable
fun MenuRow(icon: @Composable () -> Unit, label: String, onClick: () -> Unit, onLong: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLong).padding(20.dp, 11.dp), verticalAlignment = Alignment.CenterVertically) {
        icon()
        Spacer(Modifier.width(16.dp))
        Text(label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun SocialEditor(sc: Social, onDone: () -> Unit) {
    val ctx = LocalContext.current
    var u by remember { mutableStateOf(socialUrl(sc)) }
    AlertDialog(onDismissRequest = onDone, containerColor = Surf,
        title = { Text("رابط ${sc.label}", color = Color.White, fontWeight = FontWeight.Bold) },
        text = { Field(u, { u = it }, "الرابط (https://...)", uri = true) },
        confirmButton = { TextButton(onClick = { socialUrls[sc.label] = u.trim(); publish(ctx); onDone() }) { Text("حفظ", color = Gold, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onDone) { Text("إلغاء", color = Muted) } })
}

@Composable
fun TelegramPrompt(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val tg = socials.firstOrNull { it.label == "تيليجرام" }
    AlertDialog(onDismissRequest = onDone, containerColor = Surf,
        icon = { SocialIcon("تيليجرام", 56.dp) },
        title = { Text("تابعنا على تيليجرام", color = Color.White, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) },
        text = { Text("انضم لقناتنا لتصلك آخر القنوات والمباريات والتحديثات أولاً بأول.", color = Muted, textAlign = TextAlign.Center) },
        confirmButton = { TextButton(onClick = { tg?.let { openUrl(ctx, socialUrl(it)) }; onDone() }) { Text("انضم الآن", color = Gold, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onDone) { Text("لاحقاً", color = Muted) } })
}

@Composable
fun SideMenu(isOpen: Boolean, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var edit by remember { mutableStateOf<Social?>(null) }
    edit?.let { sc -> SocialEditor(sc) { edit = null } }
    BackHandler(enabled = isOpen) { onClose() }
    val ver = remember { try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (_: Exception) { "" } }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(Modifier.fillMaxSize().zIndex(5f)) {
            AnimatedVisibility(isOpen, enter = fadeIn(), exit = fadeOut()) {
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .55f))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() })
            }
            AnimatedVisibility(isOpen, modifier = Modifier.align(Alignment.CenterStart), enter = slideInHorizontally { -it }, exit = slideOutHorizontally { -it }) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Column(Modifier.fillMaxHeight().width(310.dp).background(Color(0xFF101018)).statusBarsPadding().verticalScroll(rememberScrollState())) {
                        Box(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF2B2108), Color(0xFF101018)))).padding(bottom = 16.dp)) {
                            Column {
                                Spacer(Modifier.height(12.dp))
                                Logo()
                                Text("مرحباً بك في عالم الفرجة", color = Gold, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 20.dp))
                            }
                        }
                        MenuRow({ ShareIcon() }, "مشاركة التطبيق", { shareApp(ctx) })
                        Box(Modifier.fillMaxWidth().padding(vertical = 6.dp).height(1.dp).background(Color.White.copy(alpha = .08f)))
                        Text("تابعنا على", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(20.dp, 10.dp, 20.dp, 4.dp))
                        socials.forEach { sc ->
                            MenuRow({ SocialIcon(sc.label, 36.dp) }, sc.label, { openUrl(ctx, socialUrl(sc)) }, { if (adminState.value) edit = sc })
                        }
                        if (adminState.value) Text("اضغط مطولاً على أي منصة لتعديل رابطها", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(20.dp, 6.dp))
                        Spacer(Modifier.height(24.dp))
                        Text("ohtmanTV" + (if (ver.isNotEmpty()) " • v$ver" else ""), color = Muted.copy(alpha = .6f), fontSize = 11.sp, modifier = Modifier.padding(20.dp, 12.dp))
                    }
                }
            }
        }
    }
}
